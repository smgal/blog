#include <windows.h>
#include <mmsystem.h>
#include "UMainSystem.h"

#define CLASS_NAME   "__PRG_SAMPLE__"
#define TITLE_NAME   "PRG_SAMPLE"

#define WM_IDLE      (WM_USER+666)

// Global
HINSTANCE    g_hInstance;
HWND         g_hWindow;
CMainSystem *MainSystem;


LRESULT CALLBACK WindowProc(HWND hWindow, UINT Message, WPARAM wParam, LPARAM lParam)
{
	switch (Message)
	{
		case WM_CREATE :
			timeBeginPeriod(1);
			break;
		case WM_SHOWWINDOW :
			break;
		case WM_DESTROY :
			timeEndPeriod(1); 
			PostQuitMessage(0);
		case WM_KEYDOWN     :
		case WM_KEYUP       :
			break;
		case WM_LBUTTONDOWN :
			break;
		case WM_LBUTTONUP   :
			break;
		case WM_RBUTTONDOWN :
			break;
		case WM_RBUTTONUP   :
			break;
		case WM_MOUSEMOVE   :
			break;
		case WM_IDLE        :
			if (!MainSystem->MainLoop())
				PostMessage(hWindow, WM_DESTROY, 0, 0);
			else
				Sleep(10);
			break;
	}

	return DefWindowProc(hWindow, Message, wParam, lParam);
}

int WINAPI WinMain(	HINSTANCE hInstance,
					HINSTANCE hPrevInstance,
					LPTSTR    lpCmdLine,
					int       nCmdShow)
{
	HWND hWindow;
	MSG  uMsg;


	// Ŭ���� ���
	if (hPrevInstance == 0)
	{
		WNDCLASS WinClass;

		memset(&WinClass, 0, sizeof(WinClass));

		WinClass.style         = CS_HREDRAW | CS_VREDRAW;
		WinClass.lpfnWndProc   = &WindowProc;
		WinClass.cbClsExtra    = 0;
		WinClass.cbWndExtra    = 0;
		WinClass.hInstance     = hInstance;
		WinClass.hIcon         = LoadIcon(0, IDI_APPLICATION);
		WinClass.hCursor       = LoadCursor(0, IDC_ARROW);
		WinClass.hbrBackground = (HBRUSH) GetStockObject(LTGRAY_BRUSH);
		WinClass.lpszMenuName  = CLASS_NAME;
		WinClass.lpszClassName = CLASS_NAME;

		if (RegisterClass(&WinClass) == 0)
			exit(1);
	}

	g_hInstance = hInstance;

	// ������ ����
	if (FULLSCREEN_MODE)
	{
		hWindow = CreateWindow(CLASS_NAME, TITLE_NAME,
								WS_POPUP,
								0, 0,
								MAX_X_LINE,
								MAX_Y_LINE,
								0, 0, hInstance, NULL);
		// ShowCursor(FALSE); // ��ü���� �׷��� Ŀ���� ����ϰ��� �� ��
	}
	else
	{
		RECT WindowRect;
		RECT ClientRect;

		hWindow = CreateWindow(CLASS_NAME, TITLE_NAME,
								WS_OVERLAPPEDWINDOW,
								(int) CW_USEDEFAULT, (int) CW_USEDEFAULT,
								MAX_X_LINE,
								MAX_Y_LINE,
								0, 0, hInstance, NULL);

		if (hWindow != 0)
		{
			GetWindowRect(hWindow, &WindowRect);
			WindowRect.right  -= WindowRect.left;
			WindowRect.bottom -= WindowRect.top;

			GetClientRect(hWindow, &ClientRect);

			MoveWindow(hWindow, WindowRect.left, WindowRect.top,
						MAX_X_LINE + WindowRect.right - ClientRect.right, MAX_Y_LINE + WindowRect.bottom - ClientRect.bottom, FALSE);

		}
	}

	if (hWindow == 0)
		exit(1);

	g_hWindow = hWindow;

	// ������ ��Ÿ����
	ShowWindow(hWindow, nCmdShow);
	UpdateWindow(hWindow);

	// ���� �ý��� �ʱ�ȭ
	MainSystem = new CMainSystem(hWindow);
	MainSystem->Create();

	// �޽��� ���� ����
	while (TRUE)
	{
		if (PeekMessage(&uMsg, 0, 0, 0, PM_NOREMOVE))
		{
			if (GetMessage(&uMsg, 0, 0, 0) == 0)
				break;
			TranslateMessage(&uMsg);
			DispatchMessage(&uMsg);
		}
		else {
			PostMessage(hWindow, WM_IDLE, 0, 0);
			WaitMessage();
		}
	}

	// ���� �ý��� ����
	delete MainSystem;

	return uMsg.wParam;
}
