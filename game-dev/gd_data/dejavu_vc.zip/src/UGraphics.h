
#ifndef __UGRAPHICS_H
#define __UGRAPHICS_H

#include <windows.h>
#include "UTypes.h"
#include ".\\ddraw.h"

#if 1
typedef LPDIRECTDRAW7        PDIRECTDRAW;
typedef LPDIRECTDRAWSURFACE7 PDIRECTDRAWSURFACE;
typedef DDSURFACEDESC2       SURFACEDESC;
#define IID_DIRECTDRAW       IID_IDirectDraw7
#else
typedef LPDIRECTDRAW2        PDIRECTDRAW;
typedef LPDIRECTDRAWSURFACE2 PDIRECTDRAWSURFACE;
typedef DDSURFACEDESC        SURFACEDESC;
#define IID_DIRECTDRAW       IID_IDirectDraw2
#endif

const int MAX_IMAGE_BUFFER = 10;

class CGraphics
{
public:
	CGraphics(HWND hWindow, DWORD startTickCount);
	~CGraphics();

private:
	HWND                m_hWindow;
	PDIRECTDRAW         m_directDraw;
	PDIRECTDRAWSURFACE  m_primarySurface;
	PDIRECTDRAWSURFACE  m_backBuffer;
	PDIRECTDRAWSURFACE  m_imageBuffer[MAX_IMAGE_BUFFER];
	SURFACEDESC         m_directDrawDesc;
	int                 m_depth;

	void     m_modifyClip(int &x, int &y, RECT &aRect, TSpriteMode mode);
	BOOL     m_makeItSo(HRESULT DDResult);

public:
	PDIRECTDRAWSURFACE GetFrontBuffer(void) { return m_primarySurface; };
	PDIRECTDRAWSURFACE GetBackBuffer(void) { return m_backBuffer; };
	PDIRECTDRAWSURFACE GetImageBuffer(int n) { return ((n>=0) && (n<MAX_IMAGE_BUFFER)) ? m_imageBuffer[n] : NULL; };
	HRESULT            CopyBitmap(PDIRECTDRAWSURFACE pSurface, HBITMAP hbm, int x, int y, int dx, int dy);
	PDIRECTDRAWSURFACE LoadBitmap(LPCSTR szFileName);

	int      FlippingCount;
	DWORD    StartTickCount;
	float    FlipPerSecond;

	BOOL     HangulTransparency;
	COLORREF HangulColor;
	HFONT    HangulFont;

	DWORD    ColorMatch(PDIRECTDRAWSURFACE pSurface, COLORREF color);
	HRESULT  SetColorKey(PDIRECTDRAWSURFACE pSurface, COLORREF color);
	BOOL     FillBufferRect(PDIRECTDRAWSURFACE pSurface, LPRECT pRect, COLORREF color);
	void     Flip(void);

	void     PutTile  (int x, int y, int imageNumber, RECT aRect, TSpriteMode mode);
	void     PutSprite(int x, int y, int imageNumber, RECT aRect, TSpriteMode mode);
	void     DisplayObject(TMapAttribute MA, int x, int y, short value, POINT aPoint, short aux);
	void     PutSpriteExHalf(int x, int y, int imageNumber, RECT aRect, TSpriteMode mode);
	void     PutSpriteEx(int x, int y, int imageNumber, RECT aRect, TSpriteMode mode, BYTE transparency);

	void     SetHangulColor(COLORREF color);
	void     PrintHangul(int x, int y, const char* s);
};

#endif
