
#include "UTypes.h"

POINT Point(LONG x, LONG y)
{
	POINT point = {x, y};
	return point;
}

RECT  Rect(LONG left, LONG top, LONG right, LONG bottom)
{
	RECT rect = {left, top, right, bottom};
	return rect;
}

RECT  Bounds(LONG left, LONG top, LONG width, LONG height)
{
	RECT rect = {left, top, left+width, top+height};
	return rect;
}
BOOL  InRange(INT32 Value, INT32 Min, INT32 Max)
{
	return (Min <= Value) && (Value <= Max);
}
