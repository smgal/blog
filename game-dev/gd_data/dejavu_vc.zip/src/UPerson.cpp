
#include <windows.h>

#include "UMainSystem.h"
#include "UPerson.h"

extern CMainSystem *MainSystem;

/* Start of CEventQueue */

CEventQueue::CEventQueue()
{
	ClearEvent();

	m_queue_size = MAX_EVENT_QUEUE;
	m_queue = (TEventData *)malloc(m_queue_size * sizeof(TEventData));
}

CEventQueue::~CEventQueue()
{
	free(m_queue);
}

int CEventQueue::m_prevPtr(int value)
{
	return (value > 0) ? (MAX_EVENT_QUEUE-1) : (value - 1);
}

int CEventQueue::m_nextPtr(int value)
{
	return (value < (MAX_EVENT_QUEUE-1)) ? (value + 1) : (0);
}

BOOL CEventQueue::PushEvent(TEventData *pEventMessage)
{
	if (m_head == m_nextPtr(m_tail)) 
		return FALSE;

	m_queue[m_tail] = *pEventMessage;
	m_tail = m_nextPtr(m_tail);

	return TRUE;
}

BOOL CEventQueue::UrgentPushEvent(TEventData *pEventMessage)
{
	if (m_prevPtr(m_head) == m_tail) 
		return FALSE;

	m_head = m_prevPtr(m_head);
	m_queue[m_head] = *pEventMessage;

	return TRUE;
}

BOOL CEventQueue::PopEvent(TEventData *pEventMessage)
{
	if (m_head == m_tail)
		return FALSE;

	*pEventMessage = m_queue[m_head];
	m_head = m_nextPtr(m_head);

	return TRUE;
}

void CEventQueue::ClearEvent()
{
	m_head = 0;
	m_tail = 0;
}

BOOL CEventQueue::CheckEvent(TEventData *pEventMessage)
{
	return FALSE;
}

BOOL CEventQueue::DeleteEvent(TEventData *pEventMessage)
{
	return FALSE;
}

/* Start of CCharacter */

CCharacter::CCharacter(short number, short x, short y, short job, TFaceDirection face,
					TMagicNeed personAttribute, TMapAttribute faceAttribute, BYTE maxFrame)
{
	mNumber          = number;
	mJob             = job;
	mFace            = face;
	mFaceCount       = 0;
	mTransparency    = 100;

	mFaceIncSub      = 0;
	mInMoving        = FALSE;
	mMoveStep        = 0;
	mMoveDir         = Point(0,0);

	mPersonAttribute = personAttribute;
	mFaceAttribute   = faceAttribute;
	mMaxFrame        = maxFrame;

	WarpXY(x,y);
}

CCharacter::~CCharacter()
{
}

void   CCharacter::DoAction()
{
	TEventData eventData;

	if (mInMoving)
	{
		MoveXYAuto();
		return;
	}

	if (this->PopEvent(&eventData))
	{
		switch (eventData.Type)
		{
			case _ET_MOVE :
				MoveXY((short)eventData.Param1,(short)eventData.Param2);
				break;
		}
		
	}
}

void   CCharacter::SetFace(POINT direction)
{
	if (direction.y < 0) mFace = fdUp;
	if (direction.y > 0) mFace = fdDown;
	if (direction.x < 0) mFace = fdLeft;
	if (direction.x > 0) mFace = fdRight;
}

void   CCharacter::IncFaceStep()
{
	mFaceIncSub++;

	if (mFaceIncSub >= MAX_FACE_COUNT_SUB)
	{
		mFaceCount += mFaceInc;
		if (mFaceInc > 0)
		{
			if (mFaceCount >= PERSON_FRAME)
				mFaceCount = 0;
		} 
		else 
		{
			if (mFaceCount < 0)
				mFaceCount = Pred(PERSON_FRAME);
		}
		mFaceIncSub = 0;
	}
}

short  CCharacter::GetImageNumber()
{
	short i = 0;

	if (mMaxFrame == 8)
	{
		switch (mFace) 
		{
			case fdUp    : 
				i = 6;
				break;
			case fdDown  : 
				i = 0;
				break;
			case fdLeft  : 
				i = 2;
				break;
			case fdRight : 
				i = 4;
				break;
			default      :
				i = 0;
				break;
		}
		i = Pred(mJob) * PERSON_ARRANGE + i + mFaceCount;
	}

	return i;
}

void   CCharacter::WarpXY(short x, short y)
{
    if (MainSystem)
	{
		if (MainSystem->Map)
		{
			if (InRange(x,0,Pred(MainSystem->Map->MapSize.x)) &&
				InRange(y,0,Pred(MainSystem->Map->MapSize.y)))
			{
				MainSystem->Map->Map[maPerson][mX][mY] = 0;
				mX = x;
				mY = y;
				MainSystem->Map->Map[maPerson][x][y] = (BYTE)mNumber;
			}
		}
	}
}

void   CCharacter::MoveXY(short x1, short y1)
{
	short x, y;

	if (mInMoving) 
		return;

	mMoveDir = Point(0,0);

	if (MainSystem)
	{
		if (MainSystem->Map)
		{
			if (MainSystem->Map->IsMoveableMap(mX + x1,mY + y1))
			{
				mFaceCount = mFaceCount ^ 1;
				x = mX + x1;
				y = mY + y1;
				WarpXY(x,y);
			}

			if ((mMoveDir.x != 0) || (mMoveDir.y != 0))
			{
				SetFace(mMoveDir);
				MainSystem->Map->Map[maPerson][mX+mMoveDir.x][mY+mMoveDir.y] = mNumber + 100;
				mMoveStep = 0;
				mInMoving = TRUE;
				MoveXYAuto();
			}
			else 
			{
				SetFace(Point(x1,y1));
			}
		}
	}

}

void   CCharacter::MoveXYAuto()
{
	if (!mInMoving)
		return;

	mMoveStep++;
	IncFaceStep();

	if (mMoveStep >= WALK_FRAME)
	{
		MainSystem->Map->Map[maPerson][mX][mY] = 0;
		mX        += (short)mMoveDir.x;
		mY        += (short)mMoveDir.y;
		MainSystem->Map->Map[maPerson][mX][mY] = (BYTE)mNumber;
		mInMoving = FALSE;
		mMoveDir  = Point(0,0);
   }

}

/* End of CCharacter */

/* Start of CPerson */

long	CPerson::GetAbility(TAbility element)
{
	if (InRange(element,0,Pred(MAX_TAbility)))
	{
		return mAbility[element];
	}
	return 0;
}

void	CPerson::SetAbility(TAbility element, long value)
{
	if (InRange(element,0,Pred(MAX_TAbility)))
	{
		mAbility[element] = value;
	}
}

long	CPerson::GetInternal(TInternal element)
{
	if (InRange(element,0,Pred(MAX_TInternal)))
	{
		return mInternal[element];
	}
	return 0;
}

void	CPerson::SetInternal(TInternal element, long value)
{
	if (InRange(element,0,Pred(MAX_TInternal)))
	{
		mInternal[element] = value;
	}
}

/* End of CPerson */
