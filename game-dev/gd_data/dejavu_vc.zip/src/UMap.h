
#ifndef __UMAP_H
#define __UMAP_H

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "UTypes.h"

typedef enum 
{
	FOREGROUNDTILE_TOWN,
	FOREGROUNDTILE_DEN
} FOREGROUNDTILE;

class CMap 
{
	public:
		CMap();
		CMap(char *pFileName);
		~CMap();

	private:
		char m_mapName[16];
		BYTE *m_pBuffer[MAX_TMapAttribute];

	public:
		POINT MapSize;
		FOREGROUNDTILE ForegroundTile;

		BYTE GetMap(TMapAttribute mapAttr, INT32 x, INT32 y);
		void SetMap(TMapAttribute mapAttr, INT32 x, INT32 y, BYTE Value);
		BOOL GetEventMap(TMapEvent MapEvent, INT32 x, INT32 y);
		void SetEventMap(TMapEvent MapEvent, INT32 x, INT32 y);

		BOOL IsMoveableMap(short x, short y);
		BOOL IsMoveableMap4Fog(short x, short y);
		BOOL IsForegroundTile(BYTE tile);
		BOOL IsWallTile(BYTE tile);
		BOOL LoadFromFile(char *pFileName);
		BOOL SaveToFile(char *pFileName);

		void MakeRandomMap();
		void SetFog(int x, int y);

		__declspec(property(get=GetMap,      put=SetMap      )) BYTE  Map[];
		__declspec(property(get=GetEventMap, put=SetEventMap )) BYTE  EventMap[];
};

#endif
