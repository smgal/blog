
#include <ddraw.h>
#include <time.h>
#include "UMainSystem.h"

CMainSystem::CMainSystem(HWND hWindow)
{
	srand((unsigned int)time(NULL));

	m_hWindow = hWindow;
}

CMainSystem::~CMainSystem(void)
{
	m_finalize();
}

void   CMainSystem::m_initialize(void)
{
	MainCharacter = 1;

	this->Map = new CMap();
	this->Map->LoadFromFile("Roperr.Maf");

	for (int i = 0; i <= MAX_PERSON; i++)
		this->Person[i] = NULL;

	this->Person[1] = new CCharacter(1,75,25, 1,fdRight,mnNotNeed,maPerson,8);
	this->Person[2] = new CCharacter(2,73,25,15,fdLeft ,mnNotNeed,maPerson,8);
	this->Person[2]->mTransparency = 25;
	this->Person[3] = new CCharacter(3,75,27,18,fdDown ,mnNotNeed,maPerson,8);
	this->Person[3]->mTransparency = 50;

	m_graphics = new CGraphics(m_hWindow, GetTickCount());
}

void   CMainSystem::m_finalize(void)
{
	for (int i = 1; i < MAX_PERSON; i++)
	{
		if (this->Person[i])
		{
			delete this->Person[i];
			this->Person[i] = NULL;
		}
	}

	if (this->Map)
	{
		delete this->Map;
		this->Map = NULL;
	}

	if (m_graphics)
	{
		delete m_graphics;
		m_graphics = NULL;
	}
}

/**
  * << ���� ��� ���� >>
  *
  * 1. Ÿ��
  * 2. ���� ������Ʈ       ->  ���� Ÿ�ϰ� ���� ������Ʈ ��������
  *    ( ������Ʈ�� ���� ��� �������� �� ���� )
  * 3. ��ü�� ���� ������ ����ü
  * 4. ������ �� ������Ʈ  ->  ���� Ÿ�� ��������
  *    ( ������ �ʿ� ���� Fetch ���� )
  * 5. ��� �ִ� ����ü    ->  ���� Ÿ�ϰ� ���� ������Ʈ ��������
  *                            ���� Ÿ�ϰ� ���� ������Ʈ �������� ( y-1 �϶� )
  *    ( ����ü�� �Ӽ��� ���� ���� �ٸ��� ��� ���� )
  * 6. �帷 ������Ʈ       ->  ���� Ÿ�ϰ� ��������
  **/

void   CMainSystem::m_drawScreen(void)
{
	WORD SCREEN_X_MAX = 27;
	WORD SCREEN_Y_MAX = 20;

	int   x, y;
	BYTE  value;
	POINT pitch;
	POINT origin;

	SCREEN_X_MAX = (MAX_X_LINE + Pred(TILE_X_SIZE)) / TILE_X_SIZE;
	SCREEN_Y_MAX = (MAX_Y_LINE + Pred(TILE_Y_SIZE)) / TILE_Y_SIZE;

	origin.x     = (MAX_X_LINE / TILE_X_SIZE) - SCREEN_X_MAX;
	origin.y     = 0;

	pitch	= Point(this->Person[MainCharacter]->mX - SCREEN_X_MAX / 2 - origin.x,
					this->Person[MainCharacter]->mY - SCREEN_Y_MAX / 2 - origin.y);

	if (pitch.x < 0)  
		pitch.x = 0;
	if (pitch.y < 0)
		pitch.y = 0;
	if (pitch.x > this->Map->MapSize.x - SCREEN_X_MAX)
		pitch.x = this->Map->MapSize.x - SCREEN_X_MAX;
	if (pitch.y > this->Map->MapSize.y - SCREEN_Y_MAX)
		pitch.y = this->Map->MapSize.y - SCREEN_Y_MAX;

	for (int _y = 0; _y <  SCREEN_Y_MAX; _y++) 
	for (int _x = 0; _x <= SCREEN_X_MAX; _x++)
	{
		x = _x + origin.x;
		y = _y + origin.y;

		m_graphics->DisplayObject(maTile  ,x,y,this->Map->Map[maTile  ][x+pitch.x][y+pitch.y],pitch,0);
		m_graphics->DisplayObject(maObject,x,y,this->Map->Map[maObject][x+pitch.x][y+pitch.y],pitch,0);
		m_graphics->DisplayObject(maPerson,x,y,this->Map->Map[maPerson][x+pitch.x][y+pitch.y],pitch,this->Map->Map[maObject][x+pitch.x][y+pitch.y]);
		m_graphics->DisplayObject(maField ,x,y,this->Map->Map[maField ][x+pitch.x][y+pitch.y],pitch,m_graphics->FlippingCount & 0x1);

		value = this->Map->Map[maTile][x+pitch.x][y+pitch.y];
		if (this->Map->IsForegroundTile(value))
		{
			m_graphics->DisplayObject(maTile  ,x,y,this->Map->Map[maTile  ][x+pitch.x][y+pitch.y],pitch,0);
		}

		value = this->Map->Map[maObject][x+pitch.x][y+pitch.y];
		if (IS_FOREGROUND_OBJECT_TILE(value))
		{
			m_graphics->DisplayObject(maObject,x,y,this->Map->Map[maObject][x+pitch.x][y+pitch.y],pitch,0);
		}

	}
}

void CMainSystem::m_flipPage()
{
	PDIRECTDRAWSURFACE lpFrontBuffer = m_graphics->GetFrontBuffer();
	PDIRECTDRAWSURFACE pBackBuffer  = m_graphics->GetBackBuffer();
	char szTemp[256];

	m_graphics->FlippingCount++;
	if (GetTickCount() != m_graphics->StartTickCount) 
	m_graphics->FlipPerSecond = (float)(m_graphics->FlippingCount*1000) / (GetTickCount()-m_graphics->StartTickCount);

	sprintf(szTemp,"FPS : %4.2f",m_graphics->FlipPerSecond);
	m_graphics->HangulTransparency = FALSE;
	m_graphics->SetHangulColor(RGB(0,0,0));
	m_graphics->PrintHangul(0,0,szTemp);
	m_graphics->HangulTransparency = TRUE;
	m_graphics->SetHangulColor(RGB(250,255,200));
	m_graphics->PrintHangul(100,0,"�ѱ� ��� �׽�Ʈ, ������, �˪۪�");

	m_graphics->Flip();
}

void CMainSystem::m_preProcessing()
{
	TEventData	eventData;
	int         dx = 0;
	int         dy = 0;

	if (HIBYTE(GetAsyncKeyState(VK_UP)) > 0)
		dy += -1;
	if (HIBYTE(GetAsyncKeyState(VK_DOWN)) > 0)
		dy += 1;
	if (HIBYTE(GetAsyncKeyState(VK_LEFT)) > 0)
		dx += -1;
	if (HIBYTE(GetAsyncKeyState(VK_RIGHT)) > 0)
		dx += 1;

	if (dx || dy)
	{
		eventData.Type	= _ET_MOVE;
		eventData.ID	= 0;
		eventData.Pos	= Point(dx,dy);
		SendEvent(this->Person[MainCharacter],&eventData);
	}

	for (int i = 1; i <= MAX_PERSON; i++)
	{
		if (i != MainCharacter)
		if (this->Person[i])
		if (Random(100) == 0)
		{
			eventData.Type = _ET_MOVE;
			eventData.ID = 0;
			switch (Random(4))
			{
				case 0 : 
					eventData.Pos = Point(-1,0);
					break;
				case 1 : 
					eventData.Pos = Point(1,0);
					break;
				case 2 : 
					eventData.Pos = Point(0,-1);
					break;
				case 3 : 
					eventData.Pos = Point(0,1);
					break;
			}
			SendEvent(this->Person[i],&eventData);
		}
	}
}

void   CMainSystem::Create(void)
{
	m_initialize();
}

BOOL  CMainSystem::SendEvent(CEventQueue *pEventQueue, TEventData *pEventMessage)
{
	return pEventQueue->PushEvent(pEventMessage);
}

void  CMainSystem::GetCursorPosEx(POINT *pPos)
{
	if (pPos)
	{
		GetCursorPos(pPos);
		if (!FULLSCREEN_MODE)
			ScreenToClient(m_hWindow, pPos);
	}
}

int CMainSystem::MainLoop(void)
{
	int                i;
	POINT              pos;
	PDIRECTDRAWSURFACE pBackBuffer = m_graphics->GetBackBuffer();

	// ȭ�� Clear
	m_graphics->FillBufferRect(pBackBuffer, NULL, RGB(0, 0, 80));

	m_preProcessing();

	for (i = 1; i <= MAX_PERSON; i++)
	{
		if (this->Person[i])
			this->Person[i]->DoAction();
	}

	m_drawScreen();

	GetCursorPosEx(&pos);
	m_graphics->PutSprite(pos.x, pos.y, 2, Bounds(18*25+1, 7*25+1, 24, 24), smLeftTop);

	m_flipPage();

	return 1;
}
