
#include <windows.h>
#include <ddraw.h>

#include "UGraphics.h"
#include "UMainSystem.h"

extern CMainSystem *MainSystem;

long _ABS_X = 0;
long _ABS_Y = 0;

/* Start of CGraphics */

CGraphics::CGraphics(HWND hWindow, DWORD startTickCount)
{
	m_hWindow       = hWindow;
	StartTickCount  = startTickCount;

	FlippingCount	= 0;
	StartTickCount	= 0;
	FlipPerSecond	= 0.0;

	ZeroMemory(m_imageBuffer, sizeof(m_imageBuffer));

	HangulColor		= RGB(255,255,255);
	HangulFont		= CreateFont(16,0,0,0,FW_THIN/*FW_BLACK*/,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_CHARACTER_PRECIS,
								CLIP_CHARACTER_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH,"����ü");

	DirectDrawCreateEx(NULL, (void **)&m_directDraw, IID_DIRECTDRAW, NULL);

	DDSURFACEDESC2  DDSurfaceDesc;

	if (FULLSCREEN_MODE)
	{
		DDSCAPS2 DDSCaps;

		// ��Ÿ�� Ǯ��ũ�� Ȯ��
		if (m_directDraw->SetCooperativeLevel(m_hWindow, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN | DDSCL_ALLOWREBOOT) != DD_OK)
			return;

		// ȭ�� ��� �ٲ�
		if (m_directDraw->SetDisplayMode(MAX_X_LINE, MAX_Y_LINE, COLOR_DEPTH, 0, 0) != DD_OK)
			return;

		// m_directDrawSurface ��ũ���� ����
		memset(&DDSurfaceDesc, 0, sizeof(DDSurfaceDesc));

		DDSurfaceDesc.dwSize            = sizeof(DDSurfaceDesc);
		DDSurfaceDesc.dwFlags           = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
		DDSurfaceDesc.ddsCaps.dwCaps    = DDSCAPS_COMPLEX | DDSCAPS_FLIP | DDSCAPS_PRIMARYSURFACE | DDSCAPS_3DDEVICE;
		DDSurfaceDesc.dwBackBufferCount = 1;

		// ���� ȭ�� ���� ����
		if (m_directDraw->CreateSurface(&DDSurfaceDesc, &m_primarySurface, NULL) != DD_OK)
			return;

		// �ĸ� ���� ��ü ���
		memset(&DDSCaps, 0, sizeof(DDSCaps));
		DDSCaps.dwCaps = DDSCAPS_BACKBUFFER;
		if (m_primarySurface->GetAttachedSurface(&DDSCaps, &m_backBuffer) != DD_OK)
			 return;

		m_depth = COLOR_DEPTH;
	}
	else
	{
		// �Ϲ� ������ ���
		if (m_directDraw->SetCooperativeLevel(m_hWindow, DDSCL_NORMAL) != DD_OK)
			return;

		// m_directDrawSurface ��ũ���� ����
		memset(&DDSurfaceDesc, 0, sizeof(DDSurfaceDesc));

		DDSurfaceDesc.dwSize            = sizeof(DDSurfaceDesc);
		DDSurfaceDesc.dwFlags           = DDSD_CAPS;
		DDSurfaceDesc.ddsCaps.dwCaps    = DDSCAPS_PRIMARYSURFACE;

		// ���� ȭ�� ���� ����
		if (m_directDraw->CreateSurface(&DDSurfaceDesc, &m_primarySurface, NULL) != DD_OK)
			return;

		// �ĸ� ���� ��ü ���
		memset(&DDSurfaceDesc, 0, sizeof(DDSurfaceDesc));

		DDSurfaceDesc.dwSize            = sizeof(DDSurfaceDesc);
		DDSurfaceDesc.dwFlags           = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
		DDSurfaceDesc.ddsCaps.dwCaps    = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_VIDEOMEMORY;
		DDSurfaceDesc.dwWidth           = MAX_X_LINE;
		DDSurfaceDesc.dwHeight          = MAX_Y_LINE;

		if (m_directDraw->CreateSurface(&DDSurfaceDesc, &m_backBuffer, NULL) != DD_OK)
			 return;

		{
			DDBLTFX  DDBltFx;
			DDBltFx.dwSize = sizeof(DDBltFx);
			DDBltFx.dwFillColor = 0xFF000000;
			m_backBuffer->Blt(NULL, NULL, NULL, DDBLT_COLORFILL, &DDBltFx);
		}

		{
			HDC  hDC;

			m_backBuffer->GetDC(&hDC);
			__try
			{
				m_depth = GetDeviceCaps(hDC, BITSPIXEL);
			}
			__finally
			{
				m_backBuffer->ReleaseDC(hDC);
			}
		}
	}

	m_imageBuffer[1] = LoadBitmap("Deja1.bmp");
	SetColorKey(m_imageBuffer[1], 0);
	m_imageBuffer[2] = LoadBitmap("Deja2.bmp");
	SetColorKey(m_imageBuffer[2], 0);
}

CGraphics::~CGraphics()
{
	for (int i = 0; i < MAX_IMAGE_BUFFER; i++)
	{
		if (m_imageBuffer[i])
		{
			m_imageBuffer[i]->Release();
			m_imageBuffer[i] = NULL;
		}
	}

	if (m_backBuffer)
	{
		m_backBuffer->Release();
		m_backBuffer = NULL;
	}

	if (m_primarySurface)
	{
		m_primarySurface->Release();
		m_backBuffer = NULL;
	}

	m_directDraw->Release();
	m_directDraw = NULL;

	DeleteObject(HangulFont);
}

void CGraphics::m_modifyClip(int &x, int &y, RECT &aRect, TSpriteMode mode)
{
	if (mode == smCentered)
	{
		x -= Succ(aRect.right - aRect.left) / 2;
		y -= (aRect.bottom - aRect.top);
	}

	if (x < 0)
	{
		aRect.left -= x;
		x = 0;
	}
	if (y < 0)
	{
		aRect.top -= y;
		y = 0;
	}
	if ((x + aRect.right - aRect.left) > Pred(MAX_X_LINE))
	{
		aRect.right = MAX_X_LINE + aRect.left - x;
	}
	if ((y + aRect.bottom - aRect.top) > Pred(MAX_Y_LINE))
	{
		aRect.bottom = MAX_Y_LINE + aRect.top - y;
	}
}

BOOL CGraphics::m_makeItSo(HRESULT DDResult)
{
	switch (DDResult)
	{
		case DD_OK             : return TRUE;
//		case DDERR_SURFACELOST : return (RestoreSurfaces <> DD_OK);
		default                : return (DDResult != DDERR_WASSTILLDRAWING);
	}
}

HRESULT CGraphics::CopyBitmap(PDIRECTDRAWSURFACE pSurface, HBITMAP hbm, int x, int y, int dx, int dy)
{
    HDC           hdcImage;
    HDC           hDC;
    BITMAP        bm;
    SURFACEDESC   surfaceDesc;
    HRESULT       HR;

    if (hbm == NULL || pSurface == NULL)
		return E_FAIL;

    pSurface->Restore();

    hdcImage = CreateCompatibleDC(NULL);

    SelectObject(hdcImage, hbm);

    GetObject(hbm, sizeof(bm), &bm);
    dx = dx == 0 ? bm.bmWidth  : dx;
    dy = dy == 0 ? bm.bmHeight : dy;

    surfaceDesc.dwSize  = sizeof(surfaceDesc);
    surfaceDesc.dwFlags = DDSD_HEIGHT | DDSD_WIDTH;
    pSurface->GetSurfaceDesc(&surfaceDesc);

    if ((HR = pSurface->GetDC(&hDC)) == DD_OK)
    {
		StretchBlt(hDC, 0, 0, surfaceDesc.dwWidth, surfaceDesc.dwHeight, hdcImage, x, y, dx, dy, SRCCOPY);
		pSurface->ReleaseDC(hDC);
    }

    DeleteDC(hdcImage);

    return HR;
}

PDIRECTDRAWSURFACE CGraphics::LoadBitmap(LPCSTR szFileName)
{
	PDIRECTDRAW         pDirectDraw = m_directDraw;
    HBITMAP             hbm;
    BITMAP              bm;
    SURFACEDESC         surfaceDesc;
    PDIRECTDRAWSURFACE  pSurface;

    hbm = (HBITMAP)LoadImage(GetModuleHandle(NULL), szFileName, IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION);

    if (hbm == NULL)
		hbm = (HBITMAP)LoadImage(NULL, szFileName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE|LR_CREATEDIBSECTION);

    if (hbm == NULL)
		return NULL;

    GetObject(hbm, sizeof(bm), &bm);

    ZeroMemory(&surfaceDesc, sizeof(surfaceDesc));
    surfaceDesc.dwSize = sizeof(surfaceDesc);
    surfaceDesc.dwFlags = DDSD_CAPS | DDSD_HEIGHT |DDSD_WIDTH;
    surfaceDesc.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_VIDEOMEMORY;
    surfaceDesc.dwWidth = bm.bmWidth;
    surfaceDesc.dwHeight = bm.bmHeight;

    if (pDirectDraw->CreateSurface(&surfaceDesc, &pSurface, NULL) != DD_OK)
		return NULL;

    CopyBitmap(pSurface, hbm, 0, 0, 0, 0);

    DeleteObject(hbm);

    return pSurface;
}

void CGraphics::Flip(void)
{
	if (FULLSCREEN_MODE)
	{
		m_primarySurface->Flip(NULL,DDFLIP_WAIT);
	} 
	else 
	{
		RECT rect;

		GetClientRect(m_hWindow, &rect);
		ClientToScreen(m_hWindow, (LPPOINT)&rect);
		ClientToScreen(m_hWindow, (LPPOINT)&rect+1);

		m_primarySurface->Blt(
			&rect,
			m_backBuffer,
			NULL,
			DDBLT_WAIT,
			NULL);

	}
}

DWORD CGraphics::ColorMatch(PDIRECTDRAWSURFACE pSurface, COLORREF color)
{
    COLORREF    tempColor;
    HDC         hDC;
    DWORD       dw = CLR_INVALID;
    SURFACEDESC surfaceDesc;
    HRESULT     HR;

    if (color != CLR_INVALID && pSurface->GetDC(&hDC) == DD_OK)
    {
		tempColor = GetPixel(hDC, 0, 0);
		SetPixel(hDC, 0, 0, color);
		pSurface->ReleaseDC(hDC);
    }

    surfaceDesc.dwSize = sizeof(surfaceDesc);
    while ((HR = pSurface->Lock(NULL, &surfaceDesc, 0, NULL)) == DDERR_WASSTILLDRAWING)
		;

    if (HR == DD_OK)
    {
		dw  = *(DWORD *)surfaceDesc.lpSurface;
		if(surfaceDesc.ddpfPixelFormat.dwRGBBitCount < 32)
			dw &= (1 << surfaceDesc.ddpfPixelFormat.dwRGBBitCount) - 1;
		pSurface->Unlock(NULL);
    }

    if (color != CLR_INVALID && pSurface->GetDC(&hDC) == DD_OK)
    {
		SetPixel(hDC, 0, 0, tempColor);
		pSurface->ReleaseDC(hDC);
    }

    return dw;
}

HRESULT CGraphics::SetColorKey(PDIRECTDRAWSURFACE pSurface, COLORREF color)
{
    DDCOLORKEY colorKey;

    colorKey.dwColorSpaceLowValue  = ColorMatch(pSurface, color);
    colorKey.dwColorSpaceHighValue = colorKey.dwColorSpaceLowValue;
    return pSurface->SetColorKey(DDCKEY_SRCBLT, &colorKey);
}

BOOL CGraphics::FillBufferRect(PDIRECTDRAWSURFACE pSurface, LPRECT pRect, COLORREF color)
{
    DDBLTFX     bltFX;
    HRESULT     HR;

    bltFX.dwSize = sizeof(bltFX);
    bltFX.dwFillColor = ColorMatch(pSurface,color);;

	HR = pSurface->Blt(pRect,
		                 NULL,
			             NULL,
						 DDBLT_COLORFILL | DDBLT_WAIT,
						 &bltFX);

	return (HR == DD_OK);
}

void CGraphics::PutTile(int x, int y, int imageNumber, RECT aRect, TSpriteMode mode)
{
	PDIRECTDRAWSURFACE pBackBuffer    = GetBackBuffer();
	PDIRECTDRAWSURFACE pImageBuffer = GetImageBuffer(imageNumber);

	m_modifyClip(x,y,aRect,mode);

	do
	{
	} while (!m_makeItSo(pBackBuffer->BltFast(x,y,pImageBuffer,&aRect,DDBLTFAST_NOCOLORKEY)));

}

void CGraphics::PutSprite(int x, int y, int imageNumber, RECT aRect, TSpriteMode mode)
{
	PDIRECTDRAWSURFACE pBackBuffer    = GetBackBuffer();
	PDIRECTDRAWSURFACE pImageBuffer = GetImageBuffer(imageNumber);

	m_modifyClip(x,y,aRect,mode);

	do
	{
	} while (!m_makeItSo(pBackBuffer->BltFast(x,y,pImageBuffer,&aRect,DDBLTFAST_SRCCOLORKEY)));

}

void CGraphics::PutSpriteExHalf(int x, int y, int imageNumber, RECT aRect, TSpriteMode mode)
{
	PDIRECTDRAWSURFACE  pBackBuffer  = GetBackBuffer();
	PDIRECTDRAWSURFACE  pImageBuffer = GetImageBuffer(imageNumber);
	SURFACEDESC         sourDesc;
	SURFACEDESC         destDesc;
	HRESULT             sHR;
	HRESULT             dHR;

	m_modifyClip(x,y,aRect,mode);

	ZeroMemory(&sourDesc,sizeof(sourDesc));
	ZeroMemory(&destDesc,sizeof(destDesc));

	sourDesc.dwSize = sizeof(sourDesc);
	destDesc.dwSize = sizeof(destDesc);

    while ((sHR = pImageBuffer->Lock(NULL, &sourDesc, 0, NULL)) == DDERR_WASSTILLDRAWING);
    while ((dHR = pBackBuffer->Lock(NULL, &destDesc, 0, NULL)) == DDERR_WASSTILLDRAWING);

    if ((sHR == DD_OK) && (dHR == DD_OK))
    {
		switch (m_depth)
		{
		case 32:
			{
				DWORD* pSour32;
				DWORD* pDest32;
				DWORD  MASK_WORD = 0xFEFEFEFE;

				for (int _y = 0; _y < (aRect.bottom - aRect.top); _y++)
				{
					pSour32 = (DWORD *)((DWORD)sourDesc.lpSurface + sourDesc.lPitch * (aRect.top+_y) + (aRect.left) * 4);
					pDest32 = (DWORD *)((DWORD)destDesc.lpSurface + destDesc.lPitch * (y+_y) + (x) * 4);
					for (int _x = 0; _x < (aRect.right - aRect.left); _x++)
					{
						if (*pSour32)
							*pDest32 = (DWORD)(((DWORD)(*pDest32 & MASK_WORD) + (DWORD)(*pSour32 & MASK_WORD)) >> 1);
						pSour32++;
						pDest32++;
					}
				}
			}
			break;
		case 16:
			{
				WORD* Sour;
				WORD* Dest;
				WORD  MASK_WORD = 0xF7DE;

				for (int _y = 0; _y < (aRect.bottom - aRect.top); _y++)
				{
					Sour = (WORD *)((DWORD)sourDesc.lpSurface + sourDesc.lPitch * (aRect.top+_y) + (aRect.left) * 2);
					Dest = (WORD *)((DWORD)destDesc.lpSurface + destDesc.lPitch * (y+_y) + (x) * 2);
					for (int _x = 0; _x < (aRect.right - aRect.left); _x++)
					{
						if (*Sour)
							*Dest = (WORD)(((DWORD)(*Dest & MASK_WORD) + (DWORD)(*Sour & MASK_WORD)) >> 1);
						Sour++;
						Dest++;
					}
				}
			}
			break;
		}
    }

	if (sHR == DD_OK)
		pImageBuffer->Unlock(NULL);

	if (dHR == DD_OK)
		pBackBuffer->Unlock(NULL);
}

void CGraphics::PutSpriteEx(int x, int y, int imageNumber, RECT aRect, TSpriteMode mode, BYTE transparency)
{
	// �Ķ���� ó��
	if (transparency <= 0)
		return;

	if (transparency >= 100)
	{
		PutSprite(x, y, imageNumber, aRect, mode);
		return;
	}

	if (transparency == 50)
	{
		PutSpriteExHalf(x, y, imageNumber, aRect, mode);
		return;
	}

	// ���� ������
	PDIRECTDRAWSURFACE  pBackBuffer  = GetBackBuffer();
	PDIRECTDRAWSURFACE  pImageBuffer = GetImageBuffer(imageNumber);
	SURFACEDESC         sourDesc;
	SURFACEDESC         destDesc;
	HRESULT             sHR;
	HRESULT             dHR;
	DWORD				R1, G1, B1, R2, G2, B2;

	m_modifyClip(x,y,aRect,mode);

	ZeroMemory(&sourDesc,sizeof(sourDesc));
	ZeroMemory(&destDesc,sizeof(destDesc));

	sourDesc.dwSize = sizeof(sourDesc);
	destDesc.dwSize = sizeof(destDesc);

    while ((sHR = pImageBuffer->Lock(NULL, &sourDesc, 0, NULL)) == DDERR_WASSTILLDRAWING);
    while ((dHR = pBackBuffer->Lock(NULL, &destDesc, 0, NULL)) == DDERR_WASSTILLDRAWING);

    if ((sHR == DD_OK) && (dHR == DD_OK))
    {
		switch (m_depth)
		{
		case 32:
			{
				DWORD*  pSour32;
				DWORD*  pDest32;
				DWORD   MASK_RED   = 0x00FF0000;
				DWORD   MASK_GREEN = 0x0000FF00;
				DWORD   MASK_BLUE  = 0x000000FF;
				for (int _y = 0; _y < (aRect.bottom - aRect.top); _y++)
				{
					pSour32 = (DWORD *)((DWORD)sourDesc.lpSurface + sourDesc.lPitch * (aRect.top+_y) + (aRect.left) * 4);
					pDest32 = (DWORD *)((DWORD)destDesc.lpSurface + destDesc.lPitch * (y+_y) + (x) * 4);
					for (int _x = 0; _x < (aRect.right - aRect.left); _x++)
					{
						if (*pSour32)
						{
							R1 = (*pSour32 & MASK_RED ) * transparency;
							G1 = (*pSour32 & MASK_GREEN) * transparency;
							B1 = (*pSour32 & MASK_BLUE) * transparency;
							R2 = (*pDest32 & MASK_RED ) * (100 - transparency);
							G2 = (*pDest32 & MASK_GREEN) * (100 - transparency);
							B2 = (*pDest32 & MASK_BLUE) * (100 - transparency);

							R1 = ((R1 + R2) / 100) & MASK_RED;
							G1 = ((G1 + G2) / 100) & MASK_GREEN;
							B1 = ((B1 + B2) / 100) & MASK_BLUE;

							R1 = R1 | G1 | B1;

							*pDest32 = (DWORD)R1;
						}
						pSour32++;
						pDest32++;
					}
				}
			}
			break;
		case 16:
			{
				WORD*   pSour16;
				WORD*   pDest16;
				WORD    MASK_RED   = 0xF800;
				WORD    MASK_GREEN = 0x07E0;
				WORD    MASK_BLUE  = 0x001F;
				for (int _y = 0; _y < (aRect.bottom - aRect.top); _y++)
				{
					pSour16 = (WORD *)((DWORD)sourDesc.lpSurface + sourDesc.lPitch * (aRect.top+_y) + (aRect.left) * 2);
					pDest16 = (WORD *)((DWORD)destDesc.lpSurface + destDesc.lPitch * (y+_y) + (x) * 2);
					for (int _x = 0; _x < (aRect.right - aRect.left); _x++)
					{
						if (*pSour16)
						{
							R1 = (*pSour16 & MASK_RED ) * transparency;
							G1 = (*pSour16 & MASK_GREEN) * transparency;
							B1 = (*pSour16 & MASK_BLUE) * transparency;
							R2 = (*pDest16 & MASK_RED ) * (100 - transparency);
							G2 = (*pDest16 & MASK_GREEN) * (100 - transparency);
							B2 = (*pDest16 & MASK_BLUE) * (100 - transparency);

							R1 = ((R1 + R2) / 100) & MASK_RED;
							G1 = ((G1 + G2) / 100) & MASK_GREEN;
							B1 = ((B1 + B2) / 100) & MASK_BLUE;

							R1 = R1 | G1 | B1;

							*pDest16 = (WORD)R1;
						}
						pSour16++;
						pDest16++;
					}
				}
			}
			break;
		}
    }

	if (sHR == DD_OK)
		pImageBuffer->Unlock(NULL);

	if (dHR == DD_OK)
		pBackBuffer->Unlock(NULL);
}

void CGraphics::DisplayObject(TMapAttribute MA, int x, int y, short value, POINT aPoint, short aux)
{
	RECT aRect;
	BYTE transparency;

	switch (MA)
	{
		case maTile      : 
			aRect = Bounds((value % TILE_ARRANGE)*Succ(TILE_X_SIZE)+1,(value / TILE_ARRANGE)*Succ(TILE_X_SIZE)+1,TILE_X_SIZE,TILE_Y_SIZE);
			PutTile(x*TILE_X_SIZE+_ABS_X,y*TILE_Y_SIZE+_ABS_Y,1,aRect,smLeftTop);
			break;
		case maObject    :
			if (InRange(value,1,100))
			{
				aRect = Bounds((value % OBJECT_ARRANGE)*Succ(TILE_X_SIZE)+(9*Succ(TILE_X_SIZE)+1),(value / OBJECT_ARRANGE)*Succ(TILE_Y_SIZE)+(7*Succ(TILE_Y_SIZE)+1),TILE_X_SIZE,TILE_Y_SIZE);
				PutSprite(x*TILE_X_SIZE+_ABS_X,y*TILE_Y_SIZE+_ABS_Y,2,aRect,smLeftTop);
			}
			if (value > 100)
			{
				value -= 101;
				aRect = Bounds((value % EQUIP_ARRANGE)*Succ(TILE_X_SIZE)+(18*Succ(TILE_X_SIZE)+1),(value / EQUIP_ARRANGE)*Succ(TILE_Y_SIZE)+1,TILE_X_SIZE,TILE_Y_SIZE);
				PutSprite(x*TILE_X_SIZE+_ABS_X,y*TILE_Y_SIZE+_ABS_Y,2,aRect,smLeftTop);
			}
			break;
		case maField     : 
			if ((value > 0) && !((value == __FIELD_VACUUM) || (value == __FIELD_SLEEP)))
			{
				value += aux * 8;
				aRect = Bounds((value % FIELD_ARRANGE)*Succ(TILE_X_SIZE)+(9*Succ(TILE_X_SIZE)+1),(value / FIELD_ARRANGE)*Succ(TILE_Y_SIZE)+(13*Succ(TILE_Y_SIZE)+1),TILE_X_SIZE,TILE_Y_SIZE);
				PutSpriteEx(x*TILE_X_SIZE+_ABS_X,y*TILE_Y_SIZE-10+_ABS_Y,2,aRect,smLeftTop,80);
			}
			break;
		case maAttribute :
			break;
		case maPerson    :
			if (value > 0)  
			{
				transparency = MainSystem->Person[value]->mTransparency;
				if (aux != 2)
				{
					value = MainSystem->Person[value]->GetImageNumber();
					aRect = Bounds((value % PERSON_ARRANGE)*Succ(TILE_X_SIZE)+1,(value / PERSON_ARRANGE)*Succ(TILE_Y_SIZE)+1,TILE_X_SIZE,TILE_Y_SIZE);
					PutSpriteEx(x*TILE_X_SIZE+_ABS_X,y*TILE_Y_SIZE-10+_ABS_Y,2,aRect,smLeftTop,transparency);
				}
				else 
				{
					value = 29;
					aRect = Bounds((value % OBJECT_ARRANGE)*Succ(TILE_X_SIZE)+(9*Succ(TILE_X_SIZE)+1),(value / OBJECT_ARRANGE)*Succ(TILE_Y_SIZE)+(7*Succ(TILE_Y_SIZE)+1),TILE_X_SIZE,TILE_Y_SIZE);
					PutSpriteEx(x*TILE_X_SIZE+_ABS_X,(y-1)*TILE_Y_SIZE+_ABS_Y,2,aRect,smLeftTop,transparency);
				}

				value = MainSystem->Map->Map[maTile][x+aPoint.x][y+aPoint.y-1];
				if (MainSystem->Map->IsForegroundTile((BYTE)value))
				{
					aRect = Bounds((value % TILE_ARRANGE)*Succ(TILE_X_SIZE)+1,(value / TILE_ARRANGE)*Succ(TILE_Y_SIZE)+1,TILE_X_SIZE,TILE_Y_SIZE);
					PutTile(x*TILE_X_SIZE+_ABS_X,(y-1)*TILE_Y_SIZE+_ABS_Y,1,aRect,smLeftTop);
				}

				value = MainSystem->Map->Map[maObject][x+aPoint.x][y+aPoint.y-1];
				if (IS_FOREGROUND_OBJECT_TILE(value))
				{
					aRect = Bounds((value % OBJECT_ARRANGE)*Succ(TILE_X_SIZE)+(9*Succ(TILE_X_SIZE)+1),(value / OBJECT_ARRANGE)*Succ(TILE_Y_SIZE)+(7*Succ(TILE_Y_SIZE)+1),TILE_X_SIZE,TILE_Y_SIZE);
					PutSprite(x*TILE_X_SIZE+_ABS_X,(y-1)*TILE_Y_SIZE+_ABS_Y,2,aRect,smLeftTop);
				}
			}
			break;
	}
}

void CGraphics::SetHangulColor(COLORREF color)
{
	HangulColor = color;
}

void CGraphics::PrintHangul(int x, int y, const char* s)
{
	PDIRECTDRAWSURFACE pBackBuffer = GetBackBuffer();
	HDC hDC;

	if (pBackBuffer->GetDC(&hDC) == DD_OK)
	{
		SelectObject(hDC,HangulFont);

		if (HangulTransparency)
			SetBkMode(hDC,TRANSPARENT);

		SetTextColor(hDC,HangulColor);
		TextOut(hDC,x,y,s,strlen(s));

		pBackBuffer->ReleaseDC(hDC);
	}
}

/* End of CGraphics */
