
#ifndef __UPERSON_H

#define __UPERSON_H

#include "UTypes.h"
#include "UMainSystem.h"

static INT32 MAX_FACE_COUNT_SUB = 1;
const  INT32 PERSON_FRAME       = 2;
const  INT32 PERSON_DIRECTION   = 4;
const  INT32 PERSON_ALL_FRAME   = PERSON_FRAME * PERSON_DIRECTION;
static INT32 WALK_FRAME         = 2; //MAX_FACE_COUNT_SUB * PERSON_FRAME;

class CEventQueue
{
public:
	CEventQueue();
	virtual ~CEventQueue();

private:
	int m_head;
	int m_tail;
	int m_queue_size;

	TEventData *m_queue; 

	int m_prevPtr(int value);
	int m_nextPtr(int value);

public:
	int MaskedEvent;

	// �̺�Ʈ�� Tail �� �ֱ�
	BOOL PushEvent(TEventData *EventMessage);
	// �̺�Ʈ�� Queue �� Head �� �ֱ�
	BOOL UrgentPushEvent(TEventData *EventMessage);
	// Head �� �̺�Ʈ �б�
	BOOL PopEvent(TEventData *EventMessage);
	// Queue �� ��� ���� ����
	void ClearEvent();
	// ���� Queue �� EventMessage �� �ش��ϴ� ���� �ִ��� �Ǻ�
	BOOL CheckEvent(TEventData *EventMessage);
	// ���� Queue ���� Ư�� �̺�Ʈ�� ����
	BOOL DeleteEvent(TEventData *EventMessage);
};

class CCharacter : public CEventQueue
{
public:

	CCharacter(	short number, short x, short y, short job, TFaceDirection face,
				TMagicNeed personAttribute, TMapAttribute faceAttribute, BYTE maxFrame);
	~CCharacter();

	void DoAction();

	INT32	mFaceIncSub;
	BOOL	mInMoving;
	INT32	mMoveStep;
	POINT	mMoveDir;

	short	mNumber;
	short	mJob;
	short	mX;
	short	mY;
	short	mFaceCount;
	short	mFaceInc;
	BYTE    mTransparency;

	TFaceDirection	mFace;
	TMagicNeed		mPersonAttribute;
	TMapAttribute	mFaceAttribute;
	BYTE			mMaxFrame;

	void	SetFace(POINT direction);
	void	IncFaceStep();
	short	GetImageNumber();
	void	WarpXY(short x, short y);
	void	MoveXY(short x1, short y1);
	void	MoveXYAuto();
};

class CPerson : public CCharacter
{
public:

	long	mAbility[MAX_TAbility];
	long	mInternal[MAX_TInternal];

	long	GetAbility(TAbility element);
	void	SetAbility(TAbility element, long value);

	long	GetInternal(TInternal element);
	void	SetInternal(TInternal element, long value);

	__declspec(property(get=GetAbility,  put=SetAbility )) long Ability;
	__declspec(property(get=GetInternal, put=SetInternal)) long Internal;
};

#endif