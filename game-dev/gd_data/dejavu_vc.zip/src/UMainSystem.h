
#ifndef __UMAINSYSTEM_H
#define __UMAINSYSTEM_H

#include "UGraphics.h"
#include "UMap.h"
#include "UPerson.h"

class CMainSystem
{
public:
	CMainSystem(HWND hWindow);
	~CMainSystem();

private:
	HWND        m_hWindow;
	CGraphics*  m_graphics;

	void        m_initialize(void);
	void        m_finalize(void);
	void        m_preProcessing(void);
	void        m_drawScreen(void);
	void        m_flipPage(void);

public:
	int         MainCharacter;
	CMap*       Map;
	CCharacter* Person[Succ(MAX_PERSON)];

	void        GetCursorPosEx(POINT *pPos);
	BOOL        SendEvent(CEventQueue *pEventQueue, TEventData *pEventMessage);

	void        Create(void);
	int         MainLoop(void);
};

#endif

