
#ifndef USMBASETYPE_H
#define USMBASETYPE_H

#define TD3DVector D3DXVECTOR3
#define TD3DMatrix D3DXMATRIX
#define TD3DLight9 D3DLIGHT9
#define TD3DXVector3 D3DXVECTOR3
#define TD3DPresentParameters D3DPRESENT_PARAMETERS
#define TD3DMaterial9 D3DMATERIAL9

#define single float

struct TSmPoint
{
	long x;
	long y;
};

struct TSmFPoint
{
	float x;
	float y;
};

struct TSmRect
{
	long  x, y, w, h;
	long  dx, dy;
};

class ISmActor
{
public:
	virtual unsigned long Process(long refTime = 0, ISmActor* pSender = 0) = 0;
};

class CSmActor: public ISmActor
{
public:
	unsigned long Process(long refTime = 0, ISmActor* pSender = 0)
	{
		return 0;
	};
};

#include <windows.h>

class CSmWin32App: public ISmActor
{
public:
	CSmWin32App(void) {};
	virtual ~CSmWin32App(void) {};

	unsigned long Process(long refTime = 0, ISmActor* pSender = 0)
	{
		OnCreate();

		while (TRUE)
		{
			MSG  uMsg;

			if (PeekMessage(&uMsg, 0, 0, 0, PM_NOREMOVE))
			{
				if (GetMessage(&uMsg, 0, 0, 0) == 0)
					break;
				TranslateMessage(&uMsg);
				DispatchMessage(&uMsg);
			}
			else
			{
				OnProcess();
			}
		}

		OnDestroy();

		return 0;
	}

	virtual void OnCreate(void)  {};
	virtual void OnDestroy(void) {};
	virtual void OnProcess(void) {};
};

#endif // #ifndef USMBASETYPE_H
