
#include "USmBaseType.h"

#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")

class CMyApp: public CSmWin32App 
{
private:
	HWND m_hWindow;

protected:

public:
	CMyApp(HWND hWindow): m_hWindow(hWindow) {};
	~CMyApp(void) {};

	void OnCreate(void);
	void OnDestroy(void);
	void OnProcess(void);
};

////////////////////////////////

#include <assert.h>
#include <stdio.h>

extern bool InitD3D(HWND hWnd);
extern void Cleanup(void);
extern void SetupMatrices(void);
extern void Render(void);


void CMyApp::OnCreate(void)
{
	InitD3D(m_hWindow);
}

void CMyApp::OnDestroy(void)
{
	Cleanup();
}

void CMyApp::OnProcess(void)
{
	Render();
}

////////////////////////////////

#if defined(WIN32) && defined(_DEBUG)
	extern "C" int __cdecl _CrtSetDbgFlag(int);
#endif

#if defined(WIN32) && defined(_DEBUG)
	#define ENABLE_LEAK_CHEKING _CrtSetDbgFlag(0x21);
#else
	#define ENABLE_LEAK_CHEKING
#endif

LRESULT __stdcall MsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
		case WM_DESTROY:
		{
			PostQuitMessage(0);
			return 0;
		}
		break;
		case WM_KEYDOWN:
		{
			if (wParam == VK_ESCAPE)
				PostMessage(hWnd, WM_DESTROY, 0, 0);
		}
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{
	ENABLE_LEAK_CHEKING

	WNDCLASSEX wndClass =
	{
		sizeof(WNDCLASSEX),
		CS_CLASSDC,
		MsgProc,
		0,
		0,
		GetModuleHandle(0),
		0,
		0,
		0,
		NULL,
		"SMgal_D3D",
		0
	};

	RegisterClassEx(&wndClass);

	HWND hWindow = CreateWindow("SMgal_D3D", "SMgal D3D test",
						  WS_OVERLAPPEDWINDOW, 100, 100, 640, 480,
						  GetDesktopWindow(), 0, wndClass.hInstance, NULL);

	ShowWindow(hWindow, SW_SHOWDEFAULT);
	UpdateWindow(hWindow);

	CMyApp app(hWindow);

	app.Process(0);

	return 0;
}
