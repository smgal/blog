
#ifndef USM3DFOG_H
#define USM3DFOG_H

#include "USmBaseType.h"
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

const float FOG_START =  8.0f * 1.0f;
const float FOG_END   = 15.0f * 1.0f;

class CSm3DFog: public ISmActor
{
private:
	IDirect3DDevice9* m_pD3DDevice;
	single m_fogStart;
	single m_fogEnd;

	void m_Apply(void);

public:
	CSm3DFog(IDirect3DDevice9* pD3DDevice);
	unsigned long Process(long refTime = 0, ISmActor* pSender = 0);

};

#endif // #ifndef USM3DFOG_H
