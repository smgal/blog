
#include "USm3DLight.h"

CSm3DLight::CSm3DLight(IDirect3DDevice9* pD3DDevice)
{
	TD3DXVector3 vecDirection;

	m_pD3DDevice = pD3DDevice;

	ZeroMemory(&m_light, sizeof(m_light));

	m_light.Type      = D3DLIGHT_DIRECTIONAL;
	m_light.Diffuse.r = 0.6f;
	m_light.Diffuse.g = 0.6f;
	m_light.Diffuse.b = 0.6f;
	m_light.Range     = 1000.0;

	vecDirection      = D3DXVECTOR3(-5.0, -5.0, 5.0);
	D3DXVec3Normalize((TD3DXVector3*)&m_light.Direction, &vecDirection);

	m_pD3DDevice->LightEnable(0, TRUE);
	m_pD3DDevice->SetRenderState(D3DRS_LIGHTING, 1);

	m_pD3DDevice->SetRenderState(D3DRS_AMBIENT, 0x00606060);

	m_Apply();
}

unsigned long CSm3DLight::Process(long refTime, ISmActor* pSender)
{
	return 0;
}

void CSm3DLight::m_Apply(void)
{
	m_pD3DDevice->SetLight(0, &m_light);
}
