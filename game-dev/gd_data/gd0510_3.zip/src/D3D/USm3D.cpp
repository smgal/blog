
#include "USm3DAttrib.h"

IDirect3D9*       g_pD3D = 0;
IDirect3DDevice9* g_pD3DDevice = 0;
CSm3DAttrib*      g_pD3DAttrib = 0;

///////////////////////////

bool InitD3D(HWND hWnd)
{
	TD3DPresentParameters d3dpp;
	TD3DMaterial9         mtrl;

	g_pD3D = Direct3DCreate9(D3D_SDK_VERSION);

	if (g_pD3D == NULL)
		return false;

	ZeroMemory(&d3dpp, sizeof(d3dpp));

	d3dpp.Windowed               = true;
	d3dpp.SwapEffect             = D3DSWAPEFFECT_DISCARD;
	d3dpp.BackBufferFormat       = D3DFMT_UNKNOWN;
	d3dpp.EnableAutoDepthStencil = true;
	d3dpp.AutoDepthStencilFormat = D3DFMT_D16;

#if 0
	{
		d3dpp.Windowed         = false;
		d3dpp.BackBufferCount  = 1;
		d3dpp.BackBufferFormat = D3DFMT_A8R8G8B8;
		d3dpp.BackBufferWidth  = 1024;
		d3dpp.BackBufferHeight = 768;
	}
#endif

	// Create the D3DDevice
	HRESULT result = g_pD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
							   D3DCREATE_SOFTWARE_VERTEXPROCESSING, &d3dpp, &g_pD3DDevice);

	if (FAILED(result))
		return false;

//	g_pD3DDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	g_pD3DDevice->SetRenderState(D3DRS_ZENABLE, true);

	g_pD3DDevice->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	g_pD3DDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);

	g_pD3DDevice->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	g_pD3DDevice->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);

	g_pD3DDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	g_pD3DDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	g_pD3DDevice->SetRenderState(D3DRS_BLENDOP, D3DBLENDOP_ADD);

	g_pD3DDevice->SetRenderState(D3DRS_ALPHATESTENABLE, 1);
	g_pD3DDevice->SetRenderState(D3DRS_ALPHAREF, 0x00);
	g_pD3DDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATER);

	// setup material
	ZeroMemory(&mtrl, sizeof(TD3DMaterial9));
	mtrl.Diffuse.r = 1.0f; mtrl.Ambient.r = 1.0f;
	mtrl.Diffuse.g = 1.0f; mtrl.Ambient.g = 1.0f;
	mtrl.Diffuse.b = 1.0f; mtrl.Ambient.b = 1.0f;
	mtrl.Diffuse.a = 1.0f; mtrl.Ambient.a = 1.0f;
	g_pD3DDevice->SetMaterial(&mtrl);

	// setup attribute
	g_pD3DAttrib = new CSm3DAttrib(g_pD3DDevice);

	return true;
}

void Cleanup(void)
{
	delete g_pD3DAttrib;

	if (g_pD3DDevice)
	{
		g_pD3DDevice->Release();
		g_pD3DDevice = NULL;
	}

	if (g_pD3D)
	{
		g_pD3D->Release();
		g_pD3D = NULL;
	}
}

void SetupMatrices(void)
{
	TD3DMatrix matWorld;

	D3DXMatrixIdentity(&matWorld);
	g_pD3DDevice->SetTransform(D3DTS_WORLD, &matWorld);
}

void Test(void);

void Render(void)
{
	// process key events

	if (HIBYTE(GetAsyncKeyState(VK_RIGHT)) > 0)
		g_pD3DAttrib->Camera->Angle  = g_pD3DAttrib->Camera->Angle + 0.01f;
	if (HIBYTE(GetAsyncKeyState(VK_LEFT)) > 0)
		g_pD3DAttrib->Camera->Angle  = g_pD3DAttrib->Camera->Angle - 0.01f;
	if (HIBYTE(GetAsyncKeyState(VK_UP)) > 0)
		g_pD3DAttrib->Camera->Height = g_pD3DAttrib->Camera->Height + 0.1f;
	if (HIBYTE(GetAsyncKeyState(VK_DOWN)) > 0)
		g_pD3DAttrib->Camera->Height = g_pD3DAttrib->Camera->Height - 0.1f;
	if (HIBYTE(GetAsyncKeyState('A')) > 0)
		g_pD3DAttrib->Camera->Radius = g_pD3DAttrib->Camera->Radius + 0.1f;
	if (HIBYTE(GetAsyncKeyState('Z')) > 0)
		g_pD3DAttrib->Camera->Radius = g_pD3DAttrib->Camera->Radius - 0.1f;

	if (LOBYTE(GetAsyncKeyState(VK_SPACE)) > 0)
	{
		if (g_pD3DAttrib->Projection->Mode == CSm3DProjection::pmPerspecive)
			g_pD3DAttrib->Projection->Mode = CSm3DProjection::pmOrthogonal;
		else
			g_pD3DAttrib->Projection->Mode = CSm3DProjection::pmPerspecive;
	}

	g_pD3DAttrib->Process();

	g_pD3DDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
					  D3DCOLOR_XRGB(0, 0, 0), 1.0f, 0);

	if (SUCCEEDED(g_pD3DDevice->BeginScene()))
	{
		SetupMatrices();

		Test();

		g_pD3DDevice->EndScene();
	}

	g_pD3DDevice->Present(NULL, NULL, 0, NULL);
}

////////////////////////

#include <time.h>

struct TSmVertex
{
	TD3DVector position;
	TD3DVector normal;
	TSmFPoint  texPos;
};

const int S_MAP_WIDTH  = 16;
const int S_MAP_HEIGHT = 16;

unsigned long s_map[S_MAP_WIDTH*S_MAP_HEIGHT];
int s_numVertices;
TSmVertex s_vertices[S_MAP_WIDTH*S_MAP_HEIGHT*6*5*3];

#define D3DFVF_SMVERTEX (D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1)


int MakeVertexXYZ(float x1, float y1, float z1, float x2, float y2, float z2, int tile, TSmVertex vertices[])
{
	enum TCubeVertex
	{
		cv111, cv121, cv221, cv211, cv112, cv122, cv222, cv212, cvMax
	};

	enum TTexturePos
	{
		tp00, tp10, tp01, tp11, tpMax
	};

	TD3DVector cube[cvMax];
	cube[cv111] = D3DXVECTOR3(x1, y1, z1);
	cube[cv121] = D3DXVECTOR3(x1, y2, z1);
	cube[cv221] = D3DXVECTOR3(x2, y2, z1);
	cube[cv211] = D3DXVECTOR3(x2, y1, z1);
	cube[cv112] = D3DXVECTOR3(x1, y1, z2);
	cube[cv122] = D3DXVECTOR3(x1, y2, z2);
	cube[cv222] = D3DXVECTOR3(x2, y2, z2);
	cube[cv212] = D3DXVECTOR3(x2, y1, z2);

	TSmFPoint texPos[tpMax];
	texPos[tp00].x = float(tile*36.0+2.0) / 512.0f;
	texPos[tp00].y = 2.0f / 64.0f;
	texPos[tp10].x = texPos[tp00].x + 32.0f / 512.0f;
	texPos[tp10].y = texPos[tp00].y;
	texPos[tp01].x = texPos[tp00].x;
	texPos[tp01].y = texPos[tp00].y + 32.0f / 64.0f;
	texPos[tp11].x = texPos[tp10].x;
	texPos[tp11].y = texPos[tp01].y;

	TD3DVector normal;
	int index = 0;

	if (x1 == x2)
	{
		normal = D3DXVECTOR3(1.0, 0.0, 0.0);
		D3DXVec3Normalize(&normal, &normal);
		vertices[index].position = cube[cv121]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp00]; ++index;
		vertices[index].position = cube[cv122]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp10]; ++index;
		vertices[index].position = cube[cv111]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp01]; ++index;
		vertices[index]          = vertices[index-1]; ++index;
		vertices[index]          = vertices[index-3]; ++index;
		vertices[index].position = cube[cv112]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp11]; ++index;
	}
	else if (y1 == y2)
	{
		normal = D3DXVECTOR3(0.0, 1.0, 0.0);
		D3DXVec3Normalize(&normal, &normal);
		vertices[index].position = cube[cv112]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp00]; ++index;
		vertices[index].position = cube[cv212]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp10]; ++index;
		vertices[index].position = cube[cv111]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp01]; ++index;
		vertices[index]          = vertices[index-1]; ++index;
		vertices[index]          = vertices[index-3]; ++index;
		vertices[index].position = cube[cv211]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp11]; ++index;
	}
	else if (z1 == z2)
	{
		normal = D3DXVECTOR3(0.0, 0.0, -1.0);
		D3DXVec3Normalize(&normal, &normal);
		vertices[index].position = cube[cv121]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp00]; ++index;
		vertices[index].position = cube[cv221]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp10]; ++index;
		vertices[index].position = cube[cv111]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp01]; ++index;
		vertices[index]          = vertices[index-1]; ++index;
		vertices[index]          = vertices[index-3]; ++index;
		vertices[index].position = cube[cv211]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp11]; ++index;
	}
	else
	{
		normal = D3DXVECTOR3(0.0, 0.0, z1-z2);
		D3DXVec3Normalize(&normal, &normal);
		vertices[index].position = cube[cv121]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp00]; ++index;
		vertices[index].position = cube[cv221]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp10]; ++index;
		vertices[index].position = cube[cv111]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp01]; ++index;
		vertices[index]          = vertices[index-1]; ++index;
		vertices[index]          = vertices[index-3]; ++index;
		vertices[index].position = cube[cv211]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp11]; ++index;

		normal = D3DXVECTOR3(x1-x2, 0.0, 0.0);
		D3DXVec3Normalize(&normal, &normal);
		vertices[index].position = cube[cv122]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp00]; ++index;
		vertices[index].position = cube[cv121]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp10]; ++index;
		vertices[index].position = cube[cv112]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp01]; ++index;
		vertices[index]          = vertices[index-1]; ++index;
		vertices[index]          = vertices[index-3]; ++index;
		vertices[index].position = cube[cv111]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp11]; ++index;

		normal = D3DXVECTOR3(0.0, 0.0, z2-z1);
		D3DXVec3Normalize(&normal, &normal);
		vertices[index].position = cube[cv222]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp00]; ++index;
		vertices[index].position = cube[cv122]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp10]; ++index;
		vertices[index].position = cube[cv212]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp01]; ++index;
		vertices[index]          = vertices[index-1]; ++index;
		vertices[index]          = vertices[index-3]; ++index;
		vertices[index].position = cube[cv112]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp11]; ++index;

		normal = D3DXVECTOR3(x2-x1, 0.0, 0.0);
		D3DXVec3Normalize(&normal, &normal);
		vertices[index].position = cube[cv221]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp00]; ++index;
		vertices[index].position = cube[cv222]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp10]; ++index;
		vertices[index].position = cube[cv211]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp01]; ++index;
		vertices[index]          = vertices[index-1]; ++index;
		vertices[index]          = vertices[index-3]; ++index;
		vertices[index].position = cube[cv212]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp11]; ++index;

		normal = D3DXVECTOR3(0.0, y2-y1, 0.0);
		D3DXVec3Normalize(&normal, &normal);
		vertices[index].position = cube[cv122]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp00]; ++index;
		vertices[index].position = cube[cv222]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp10]; ++index;
		vertices[index].position = cube[cv121]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp01]; ++index;
		vertices[index]          = vertices[index-1]; ++index;
		vertices[index]          = vertices[index-3]; ++index;
		vertices[index].position = cube[cv221]; vertices[index].normal = normal; vertices[index].texPos = texPos[tp11]; ++index;
	}

	return index;
}

int Map2Vertives(const unsigned long map[], int mapSize, int mapTPL, TSmVertex vertices[])
{
	int x, z;
	int tile, height;
	int wMap = mapTPL;
	int hMap = mapSize / wMap;
	int numVertices = 0;

	for (int hLoop = 0; hLoop < hMap; hLoop++)
	for (int wLoop = 0; wLoop < wMap; wLoop++)
	{
		x = wLoop - wMap / 2;
		z = hLoop - hMap / 2;
		tile = map[hLoop*mapTPL+wLoop] & 0xFFFF;
		height = map[hLoop*mapTPL+wLoop] >> 16;

		if (height == 0)
		{
			numVertices += MakeVertexXYZ(-0.5f+x*1.0f, 0.0f, -0.5f+z*1.0f, 0.5f+x*1.0f, 0.0f, 0.5f+z*1.0f, tile, &vertices[numVertices]);
		}
		else
		{
			for (int zMap = 0; zMap < height; zMap++)
			{
				numVertices += MakeVertexXYZ(-0.5f+x*1.0f, zMap*1.0f, -0.5f+z*1.0f, 0.5f+x*1.0f, (zMap+1)*1.0f, 0.5f+z*1.0f, tile, &vertices[numVertices]);
			}
		}
	}

	return numVertices;
}
#include <stdio.h>
void Test(void)
{
	static bool s_isFirst = true;
	static IDirect3DTexture9* s_pTexture = NULL;
	static IDirect3DTexture9* s_pSprite  = NULL;

	single    angle;
	TSmVertex vertices[4];

	if (s_isFirst)
	{
		D3DXCreateTextureFromFileA(g_pD3DDevice, "./tile.bmp", &s_pTexture);
		D3DXCreateTextureFromFileA(g_pD3DDevice, "./chara.png", &s_pSprite);

		srand(time(NULL));
		for (int y = 0; y < S_MAP_HEIGHT; y++)
		{
			for (int x = 0; x < S_MAP_WIDTH; x++)
			{
				switch (rand() % 10)
				{
					case 0:
					case 1:
					case 2:
					case 3:
					case 4:
					case 5:
					case 6:
					case 7:
						s_map[y*S_MAP_WIDTH + x] = ((0) << 16) | 8;
						break;
					case 8:
						s_map[y*S_MAP_WIDTH + x] = ((1) << 16) | 4;
						break;
					case 9:
						s_map[y*S_MAP_WIDTH + x] = ((0) << 16) | 6;
						break;
				}
			}
		}
		s_numVertices = Map2Vertives(s_map, sizeof(s_map) / sizeof(s_map[0]), S_MAP_WIDTH, s_vertices);
		s_isFirst = false;
	}

	g_pD3DDevice->SetTexture(0, s_pTexture);
	g_pD3DDevice->SetFVF(D3DFVF_SMVERTEX);
	g_pD3DDevice->DrawPrimitiveUP(D3DPT_TRIANGLELIST, s_numVertices / 3, s_vertices, sizeof(TSmVertex));

	g_pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, 1);
	{
		TSmFPoint player[] =
		{
			{ 0.0f, 0.0f },
			{ 1.0f, 1.0f },
		};

		angle = g_pD3DAttrib->Camera->Angle;

		for (int i = 0; i < sizeof(player) / sizeof(player[0]); i++)
		{
			vertices[0].position = D3DXVECTOR3(float(player[i].x - 0.5f * sin(angle)), 1.0f, float(player[i].y + 0.5f * cos(angle)));
			vertices[0].normal   = D3DXVECTOR3(0.0f, 0.0f, -1.0f);
			vertices[0].texPos.x = 0.0;
			vertices[0].texPos.y = 0.0;
			vertices[1].position = D3DXVECTOR3(float(player[i].x + 0.5f * sin(angle)), 1.0f, float(player[i].y - 0.5f * cos(angle)));
			vertices[1].normal   = vertices[0].normal;
			vertices[1].texPos.x = 1.0;
			vertices[1].texPos.y = 0.0;
			vertices[2].position = D3DXVECTOR3(vertices[0].position.x, 0.0f, vertices[0].position.z);
			vertices[2].normal   = vertices[0].normal;
			vertices[2].texPos.x = 0.0;
			vertices[2].texPos.y = 1.0;
			vertices[3].position = D3DXVECTOR3(vertices[1].position.x, 0.0f, vertices[1].position.z);
			vertices[3].normal   = vertices[0].normal;
			vertices[3].texPos.x = 1.0;
			vertices[3].texPos.y = 1.0;

			g_pD3DDevice->SetTexture(0, s_pSprite);
			g_pD3DDevice->SetFVF(D3DFVF_SMVERTEX);
			g_pD3DDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, vertices, sizeof(TSmVertex));
		}
	}
	g_pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, 0);
}
