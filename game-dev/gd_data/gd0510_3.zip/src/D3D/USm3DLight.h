
#ifndef USM3DLIGHT_H
#define USM3DLIGHT_H

#include "USmBaseType.h"
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

class CSm3DLight: public ISmActor
{
private:
	IDirect3DDevice9* m_pD3DDevice;
	TD3DLight9 m_light;

	void m_Apply(void);

public:
	CSm3DLight(IDirect3DDevice9* pD3DDevice);

	unsigned long Process(long refTime = 0, ISmActor* pSender = 0);
};

#endif // #ifndef USM3DLIGHT_H
