
#ifndef USM3DATTRIB_H
#define USM3DATTRIB_H

#include "USmBaseType.h"
#include "USm3DCamera.h"
#include "USm3DProjection.h"
#include "USm3DLight.h"
#include "USm3DFog.h"

#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

class CSm3DAttrib: public ISmActor
{
private:
	IDirect3DDevice9* m_pD3DDevice;
	CSm3DCamera* m_camera;
	CSm3DProjection* m_projection;
	CSm3DLight* m_light;
	CSm3DFog* m_fog;

public:
	CSm3DAttrib::CSm3DAttrib(IDirect3DDevice9* pD3DDevice);
	~CSm3DAttrib(void);

	unsigned long Process(long refTime = 0, ISmActor* pSender = 0);

	inline CSm3DCamera* GetCamera(void) { return m_camera; }
	inline CSm3DProjection* GetProjection(void) { return m_projection; }

	__declspec( property( get = GetCamera ) ) CSm3DCamera* Camera;
	__declspec( property( get = GetProjection ) ) CSm3DProjection* Projection;
};

#endif // #ifndef USM3DATTRIB_H
