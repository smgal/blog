/*

   This program is animation player for AutoDesk Animater

   Before source made sohn dongik 1992.11

   Source rebuild MG. ( MulGeal ) Software Production

   rebuild ver 0.4

   date : 93.10.01

   rebuild : YoungJin Ju

   PS : next version 93.10.15

*/


#pragma inline
#include <time.h>
#include <stdio.h>
#include <alloc.h>
#include <dos.h>

/*
 * �� FLIC file�� �ִ� frame�� (�� program������ ��� ����).
 */
#define FLI_MAXFRAMES		4000

#define FLIH_MAGIC		0xaf11		/* FLIC file �ĺ� code	*/
#define FLIF_MAGIC		0xf1fa		/* FLIC frame �ĺ� code	*/

/*
 * FLIC file header ����.
 */
typedef struct {
	long		Size;		/* FLIC file�� size		*/
	unsigned	Type;		/* FLIC file�� �ĺ� code	*/
	unsigned	FrameCount;	/* frame ����			*/
	unsigned	Width;		/* ȭ�� ��			*/
	unsigned	Height;		/* ȭ�� ����			*/
	unsigned	BPP;		/* pixel�� bit��(Bits Per Pixel)*/
	int 		Flags;
	int 		Speed;		/* playing �ӵ�			*/
	long		NextHead;	/* ���� FLIC file header ��ġ?  */
	long		FramesInTable;
	int 		File;
	long		Frame1Off;
	long		Strokes;
	long		Session;
	char		Reserved[88];
	} FLIHEAD;

/*
 * �� frame header�� ����.
 */
typedef struct {
	long		Size;		/* �� frame�� size		*/
	unsigned	Type;		/* frame �ĺ� code		*/
	int		Chunks;		/* chunk�� ����			*/
	char		Pad[8];		/* �̻��			*/
	} FLIFRAME;

/*
 * �� chunk header�� ����.
 */
typedef struct {
	long		Size;		/* �� chunk�� size		*/
	unsigned	Type;		/* chunk type(�Ʒ��� ����)	*/
	} FLICHUNK;

typedef struct{
	unsigned re;
	char Skip;
	char Change;
	} PAL_BUF;

/*
 * chunk type�� ����.
 */
#define FLI_COLOR	11	/* palette update�� ����� chunk type	*/
#define FLI_LC		12	/* line compress image data chunk type	*/
#define FLI_BLACK	13	/* ȭ���� black���� set�ϴ� chunk type	*/
#define FLI_BRUN	15	/* RLE compress image data chunk type	*/
#define FLI_COPY	16	/* non-compress image data chunk type	*/

/*
 * program error ����.
 */
#define SUCCESS			0
#define ERR_READ		1
#define ERR_WRITE		2
#define ERR_ALLOC		3
#define ERR_INV_FLIFRAME	4
#define ERR_INV_CHUNK		5
#define ERR_INV_COMP		6

char far 	*FirstScreen;		/* ù frame image data buffer	*/
int 		FirstFlag = 0;		/* ù frame decompress flag	*/
unsigned long f = (unsigned long)sizeof(FLIHEAD);
unsigned long fCount;
long     time1;


int hopen ( const char *name , const char mode )
{
  asm push ds
  asm lds dx,name
  asm mov ah,3dh
  asm mov al,mode
  asm int 21h
  asm pop ds
  asm jc l00
  asm jmp l01
l00:
  return -1;
l01:
  return _AX;
}

int hclose ( int handle )
{
  asm mov ah,3eh
  asm mov bx,handle
  asm jc  l00
  asm jmp l01

l00:
  return EOF;
l01:
  return NULL;
}

unsigned hread ( char *buf , unsigned size , int handle )
{
  asm push ds
  asm lds  dx,buf
  asm mov  ah,3fh
  asm mov  bx,handle
  asm mov  cx,size
  asm int  21h
  asm pop  ds
  asm jc  l00
  asm jmp l01
l00:
  return NULL;
l01:
  return _AX;
}


int hseek ( int handle , long len , char whence )
{
  asm push ds
  asm lds  dx,len
  asm mov  cx,ds
  asm pop  ds
  asm mov  ah,42h
  asm mov  al,whence
  asm mov  bx,handle
  asm int  21h
}

void SetMode(mode)
unsigned char mode;
{
  asm 
asm    mov ah,0
asm    mov al,mode
asm    int 10h
asm   
}

void SetVGAPalette( char *palette, unsigned skip, unsigned change)
{
  asm 
asm    les dx,palette
asm    mov ax,1012h
asm    mov bx,skip
asm    mov cx,change
asm    int 10h
asm   
}

int DoPalette(int fp, unsigned size)
{

  PAL_BUF       pa;
  char		Palette[768];
  unsigned	rSize,buf;

  rSize = hread((char *)&pa,sizeof(PAL_BUF),fp);
  if(rSize != sizeof(PAL_BUF)) return ERR_READ;
  if(!pa.Skip && !pa.Change) buf = 256;
  else buf = pa.Change;
  if(hread(Palette,size - 4,fp) != size - 4) return ERR_READ;
  SetVGAPalette(Palette,pa.Skip,buf);
  return SUCCESS;
}

int DoRLE(int fp, unsigned size)
{
  char far   *buff;
  unsigned   Count,iCount = 0,k = 0;
  char	     c;
  int	     Packets;

  if(FirstFlag) {
    fCount = (unsigned long)sizeof(FLIHEAD);
    movedata(FP_SEG(FirstScreen),FP_OFF(FirstScreen),0xa000,0,64000);
    return SUCCESS;
  }
  if((buff = farmalloc(size)) == NULL) return ERR_ALLOC;
  if(hread(buff,size,fp) != size) return ERR_READ;
  while(iCount < 64000) {
    Packets = (int)*(buff + k++) & 0x00ff;
    while(Packets--) {
      Count = (unsigned)*(buff + k++) & 0x00ff;
      if(Count == 0) goto END;
      else if(Count > 127) {
	Count = 256 - Count;
	while(Count--)
	  *(FirstScreen + iCount++) = *(buff + k++);
      }else{
	c = *(buff + k++);
	while(Count--) *(FirstScreen + iCount++) = c;
      }
    }
  }

END:
  movedata(FP_SEG(FirstScreen),FP_OFF(FirstScreen),0xa000,0,64000);
  farfree(buff);
  FirstFlag = 1;
  return SUCCESS;
}


/*
int DoRLE(fp,size)
FILE *fp;
unsigned size;
{
  char far	*buff;

  asm 
asm   cmp FirstFlag,0
asm   je l0
asm   push ds
asm   lds si,FirstScreen
asm   mov ax,0a000h
asm   mov es,ax
asm   xor di,di
asm   mov cx,32000
asm   rep movsw
asm   pop ds
asm   

  fCount = f;
  return SUCCESS;

  l0:
  if((buff = farmalloc(size)) == NULL) return ERR_ALLOC;
  if(hread(buff,1,size,fp) != size) return ERR_READ;

  asm 
asm   xor dx,dx
asm   xor bx,bx
asm   xor cx,cx
asm   push ds
asm   lds si,buff
asm   

  l00:
  asm 
asm    cmp dx,64000
asm    jge l10
asm    mov cl,ds:[bx+si]
asm    inc bx
asm   

  l01:
  asm 
asm    cmp cl,0
asm    je l00
asm    push cx
asm    mov cl,ds:[bx+si]
asm    inc bx
asm    cmp cl,0
asm    je l09
asm    cmp cl,127
asm    jle l03
asm   

  l02:
  asm 
asm    les di,FirstScreen
asm    mov al,ds:[bx+si]
asm    inc bx
asm    add di,dx
asm    add dx,cx
asm    rep stosb
asm    jmp l04
asm   

  l03:
  asm 
asm    not cl
asm    inc cx
asm    push si
asm    les di,FirstScreen
asm    add di,dx
asm    add si,bx
asm    add bx,cx
asm    add dx,cx
asm    rep movsb
asm    pop si
asm   

  l04:
  asm 
asm    pop cx
asm    loop l01
asm   

  l09:
  asm 
asm    pop cx
asm   

  l10:
  asm 
asm   lds si,FirstScreen
asm   mov ax,0a000h
asm   mov es,ax
asm   xor di,di
asm   mov cx,32000
asm   rep movsw
asm   pop ds
asm   

  farfree(buff);
  FirstFlag = 1;
  return SUCCESS;
}*/

void DoBlackScreen(void)
{
  asm 
asm    mov ax,0a000h
asm    mov es,ax
asm    xor di,di
asm    mov ax,0
asm    mov cx,32000
asm    rep stosw
asm   
}

int DoCopy(int fp, unsigned size)
{
  char far *buff;

  if((buff = farmalloc(size)) == NULL) return ERR_ALLOC;
  if(hread(buff,size,fp) != size) return ERR_READ;

  asm 
asm    push ds
asm    lds si,buff
asm    mov ax,0a000h
asm    mov es,ax
asm    xor di,di
asm    mov cx,size
asm    rep movsb
asm    pop ds
asm   

  return SUCCESS;
}

int DoLC(int fp, unsigned size)
{
  long          time1;
  char far	*buff;

  if((buff = farmalloc(size)) == NULL) return ERR_ALLOC;
  if(hread(buff,size,fp) != size) return ERR_READ;

  asm 
asm   push ds
asm   lds si,buff
asm   mov ax,0a000h
asm   mov es,ax
asm   lodsw
asm   mov dx,ax
asm   lodsw
asm   mov cx,ax
asm   xchg dh,dl
asm   mov bx,dx
asm   shr bx,1
asm   shr bx,1
asm   add dx,bx
asm   mov di,dx
asm   

  l00:
  asm 
asm    cmp cx,0
asm    je l06
asm    push di
asm    push cx
asm    xor ch,ch
asm    lodsb
asm    mov cl,al
asm   

  l01:
  asm 
asm    cmp cl,0
asm    je l05
asm    push cx
asm    xor ah,ah
asm    lodsb
asm    add di,ax
asm    xor ch,ch
asm    lodsb
asm    mov cl,al
asm    cmp cl,7fh
asm    jbe l02
asm    jmp l07
asm   

  l02:
  asm 
asm    cmp cx,0
asm    je l03
asm    jmp l09
asm   

  l03:
  asm 
asm    pop cx
asm    pop cx
asm    pop ds
asm   
    return ERR_INV_COMP;

  l04:
  asm 
asm    pop cx
asm    loop l01
asm   

  l05:
  asm 
asm    pop cx
asm    pop di
asm    add di,320
asm    loop l00
asm   

  l06:
    asm 
asm     pop ds
asm     jmp l11
asm     


  l07:
  asm 
asm    not cl
asm    inc cx
asm    lodsb
asm    cld
asm    rep stosb
asm    jmp l04
asm   

  l08:
  asm 
asm    not cl
asm    inc cx
asm    lodsb
asm    mov ah,al
asm    shr cx,1
asm    cld
asm    rep stosw
asm    jmp l04
asm   

  l09:
  asm 
asm    cld
asm    rep movsb
asm    jmp l04
asm   

  l10:
  asm 
asm    shr cx,1
asm    cld
asm    rep movsw
asm    jmp l04
asm   

  l11:

  farfree(buff);
  return SUCCESS;
}

int DoChunk(int fp)
{
  FLICHUNK	fliChunk;
  unsigned	rSize;
  int		rtn;

  rSize = hread((char *)&fliChunk,sizeof(FLICHUNK),fp);

  if(rSize != sizeof(FLICHUNK)) return ERR_READ;

  switch(fliChunk.Type) {
    case FLI_COLOR:
      rtn = DoPalette(fp,fliChunk.Size - sizeof(FLICHUNK));
      if(rtn != SUCCESS) return rtn;
      break;

    case FLI_LC:
      rtn = DoLC(fp,fliChunk.Size - sizeof(FLICHUNK));
      if(rtn != SUCCESS) return rtn;
      break;

    case FLI_BLACK:
      DoBlackScreen();
      break;

    case FLI_BRUN:
      rtn = DoRLE(fp,fliChunk.Size - sizeof(FLICHUNK));
      if(rtn != SUCCESS) return rtn;
      break;

    case FLI_COPY:
      rtn = DoCopy(fp,fliChunk.Size - sizeof(FLICHUNK));
      if(rtn != SUCCESS) return rtn;
      break;

    default:
      return ERR_INV_CHUNK;
  }

  return SUCCESS;
}

int DoOneFrame(int fp)
{
  FLIFRAME	fliFrame;
  unsigned	rSize;
  int		i,rtn;


  rSize = hread((char *)&fliFrame,sizeof(FLIFRAME),fp);

  if(rSize != sizeof(FLIFRAME)) return ERR_READ;
  if(fliFrame.Type != FLIF_MAGIC) return ERR_INV_FLIFRAME;
    for(i = 0; i < fliFrame.Chunks; i++) {
      rtn = DoChunk(fp);
      if(rtn != SUCCESS) return rtn;
    }

  fCount += fliFrame.Size;
  hseek(fp,fCount,SEEK_SET);
  return SUCCESS;
}

void main(int argc, char *argv[])
{
  int 	    fp;
  FLIHEAD   fliHead;
  unsigned  rSize;
  int	    Frames = 0;
  int	    rtn;


  time1 = biostime ( 1 , 0l );

  fCount = f;

  if(argc != 2) {
    puts("Usage: aaplay flic_file_name");
    exit(1);
  }

  if((fp = hopen(argv[1],0)) == -1) {
    puts("can't find file !");
    exit(1);
  }

  rSize = hread((char *)&fliHead,sizeof(FLIHEAD),fp);

  if(rSize != sizeof(FLIHEAD)) {
    puts("Read Error !");
    hclose(fp);
    exit(1);
  }

  if(fliHead.Type != FLIH_MAGIC) {
    puts("Not flic animation file !");
    hclose(fp);
    exit(1);
  }

  if((FirstScreen = farmalloc(64000)) == NULL) {
    puts("memory allocation error !");
    hclose(fp);
    exit(1);
  }

  SetMode(0x13);

  while(1){
    if((rtn = DoOneFrame(fp)) == ERR_INV_COMP) {
      SetMode(0x03);
      farfree(FirstScreen);
      printf("Error Code: %d",rtn);
      hclose(fp);
      exit(1);
    }

    if(kbhit()) {
      if(!getch()) getch();
      break;
    }

    if(Frames++ >= fliHead.FrameCount) {
      time1 = biostime ( 0 , 0l );
      printf ( "%f" , time1 / CLK_TCK );
      getch();
      time1 = biostime ( 1 , 0l );
      Frames = 0;
      hseek(fp,(long)sizeof(FLIHEAD),SEEK_SET);
    }
  }

  SetMode(0x03);
  farfree(FirstScreen);
  hclose(fp);
}
