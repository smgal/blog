
#include "convert2ucs.h"
#include <string.h>

int main()
{
	wchar_t szDst[100];
	char*   szSrc = "1����av�c";

	ConvertUHC2UCS2(szDst, sizeof(szDst) / sizeof(szDst[0]), szSrc, strlen(szSrc)+1);

	return 0;
}
