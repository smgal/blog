
#if !defined(_CONVERT2UCS_H_)
#define _CONVERT2UCS_H_

#include <wchar.h>

wchar_t* ConvertUHC2UCS2(wchar_t* pDst, int dstSize, char* pSrc, int srcSize, wchar_t errChar = 0x20);

#endif
