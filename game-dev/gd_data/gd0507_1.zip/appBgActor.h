
#ifndef APP_BG_ACTOR_H
#define APP_BG_ACTOR_H

#include "smType.h"
#include "smVideo.h"

class CBackgroundActor: public CSmRenderer
{
private:
	long  m_image;
	float m_xDest, m_yDest;

public:
	CBackgroundActor(long image);

	unsigned long DoAction(long refTime, ISmActor* pSender = 0);
	void Render(void);
};

#endif
