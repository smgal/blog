
#include "appRotator.h"
#include "smVtxBuffer.h"
#include <windows.h>
#include <assert.h>

unsigned long CRotator::DoAction(long refTime, ISmActor* pSender)
{
	#define ROTATING_ANGLE 1.0f

	CSmVertexBuffer* pVB = static_cast<CSmVertexBuffer*>(pSender);
	assert(pVB);

	if (HIBYTE(GetAsyncKeyState(VK_RIGHT)) > 0)
		pVB->SetAngleY(pVB->GetAngleY() + ROTATING_ANGLE);
	if (HIBYTE(GetAsyncKeyState(VK_LEFT)) > 0)
		pVB->SetAngleY(pVB->GetAngleY() - ROTATING_ANGLE);
	if (HIBYTE(GetAsyncKeyState(VK_DOWN)) > 0)
		pVB->SetAngleX(pVB->GetAngleX() - ROTATING_ANGLE);
	if (HIBYTE(GetAsyncKeyState(VK_UP)) > 0)
		pVB->SetAngleX(pVB->GetAngleX() + ROTATING_ANGLE);
	if (HIBYTE(GetAsyncKeyState('A')) > 0)
		pVB->SetAngleZ(pVB->GetAngleZ() + ROTATING_ANGLE);
	if (HIBYTE(GetAsyncKeyState('Z')) > 0)
		pVB->SetAngleZ(pVB->GetAngleZ() - ROTATING_ANGLE);

	#undef ROTATING_ANGLE

	return 0;
}
