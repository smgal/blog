
#include "smVtxBuffer.h"
#include "smVideoGL.h"
#include <windows.h>
#include <gl/gl.h>
#include <assert.h>

CSmVertexBuffer::CSmVertexBuffer(VERTEX *pSmVertices, int num)
: m_pActor(NULL), m_pRenderer(NULL), m_nVertices(0), m_pVertices(NULL)
{
	if ((pSmVertices != NULL) && (num > 0))
	{
		m_pVertices = new VERTEX[num];
		assert(m_pVertices);

		memcpy(m_pVertices, pSmVertices, num * sizeof(VERTEX));

		m_nVertices = num;
	}
	else
	{
		m_pVertices = NULL;
		m_nVertices = 0;
	}

	memset(&m_angle, 0, sizeof(m_angle));
}

CSmVertexBuffer::~CSmVertexBuffer(void)
{
	if (m_pActor)
		delete m_pActor;

	if (m_pRenderer)
		delete m_pRenderer;

	delete[] m_pVertices;
};

void CSmVertexBuffer::SetActor(ISmActor* pActor)
{
	if (m_pActor)
		delete m_pActor;

	m_pActor = pActor;
}

void CSmVertexBuffer::SetRenderer(CSmRenderer* pRenderer)
{
	if (m_pRenderer)
		delete m_pRenderer;

	m_pRenderer = pRenderer;
}

unsigned long CSmVertexBuffer::DoAction(long refTime, ISmActor* pSender)
{
	if (m_pRenderer)
		return m_pRenderer->DoAction(refTime, this);

	if (m_pActor)
		return m_pActor->DoAction(refTime, this);

	return 0;
}

void CSmVertexBuffer::Render(void)
{
	if (m_pRenderer)
	{
		m_pRenderer->Render();
		return;
	}

	if ((m_pVertices == NULL) || (m_nVertices <= 0))
		return;

	glLoadIdentity();
	glTranslatef(0.0f, 0.0f, c_xViewport*c_scaleFactor);
	glScalef(c_scaleFactor, c_scaleFactor, c_scaleFactor);
	glRotatef(m_angle[0], 1.0f, 0.0f, 0.0f);
	glRotatef(m_angle[1], 0.0f, 1.0f, 0.0f);
	glRotatef(m_angle[2], 0.0f, 0.0f, 1.0f);

	GLuint currTexture = -1;
	
	glEnable(GL_TEXTURE_2D);

	for (int i = 0; i < m_nVertices; i++)
	{
		VERTEX*    pVertex  = &m_pVertices[i];
		GLTEXTURE* pTexture = (GLTEXTURE*)pVertex->image;

		if (currTexture != pTexture->ixTexture)
		{
			glBindTexture(GL_TEXTURE_2D, pTexture->ixTexture);
			currTexture = pTexture->ixTexture;
		}

		glPushMatrix();

		glScalef(pVertex->scale, pVertex->scale, pVertex->scale);

		glBegin(GL_TRIANGLE_STRIP);
		{
			glColor4fv(pVertex->color);

			for (int j = 0; j < 4; j++)
			{
				glTexCoord2f(pVertex->uv[j][0] / pTexture->wTexture, pVertex->uv[j][1] / pTexture->hTexture);
				glVertex3fv(pVertex->vertex[j]);
			}
		}
		glEnd();

		glPopMatrix();
	}
}
