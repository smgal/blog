
#include "smVideoGL.h"

///////////////////////

CSmVideoGL s_video(0);

ISmVideo* GetVideoInstance(void)
{
	if (!s_video.IsValid())
		s_video.Create(c_screenWidth, c_screenHeight, c_screenDepth, false);

	return &s_video;
}

///////////////////////

#include <assert.h>

#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "opengl32.lib")
//#pragma comment(lib, "glu32.lib")

#define CHECK_FAILED(cond) if (!(cond)) return false;
#define CHECK_FAILED_THROW(cond) if (!(cond)) throw 0;
#define RELASE_AND_NIL(pComObject) if (pComObject) { pComObject->Release(); pComObject = NULL; }

#define CLASS_NAME    "__������__"
#define TITLE_NAME    "������"

CSmVideoGL::CSmVideoGL(HINSTANCE hInstance)
: m_hInstance(hInstance), m_hRC(0), m_hWindow(0), m_hDC(0)
{
}

CSmVideoGL::~CSmVideoGL(void)
{
}

LRESULT CALLBACK s_WindowProc(HWND hWindow, UINT Message, WPARAM wParam, LPARAM lParam)
{
	switch (Message)
	{
		case WM_CREATE :
			timeBeginPeriod(1);
			break;
		case WM_DESTROY :
			timeEndPeriod(1); 
			PostQuitMessage(0);
			return 0;
		case WM_KEYUP       :
			if (wParam == 27)
				s_WindowProc(hWindow, WM_CLOSE, 0, 0);
			break;
	}

	return DefWindowProc(hWindow, Message, wParam, lParam);
}

bool CSmVideoGL::m_IntializeWindow(long width, long height)
{
	WNDCLASS winClass =
	{
		CS_HREDRAW | CS_VREDRAW, &s_WindowProc, 0, 0, m_hInstance,
		LoadIcon(0, IDI_APPLICATION), LoadCursor(0, IDC_ARROW),
		(HBRUSH) GetStockObject(LTGRAY_BRUSH), NULL, CLASS_NAME
	};

	CHECK_FAILED(RegisterClass(&winClass))

	m_hWindow = CreateWindow(CLASS_NAME, TITLE_NAME, WS_OVERLAPPEDWINDOW, (int) CW_USEDEFAULT, (int) CW_USEDEFAULT,
						     width, height, 0, 0, m_hInstance, NULL);

	CHECK_FAILED(m_hWindow)

	{
		RECT WindowRect;
		RECT ClientRect;

		GetWindowRect(m_hWindow, &WindowRect);
		WindowRect.right  -= WindowRect.left;
		WindowRect.bottom -= WindowRect.top;

		GetClientRect(m_hWindow, &ClientRect);

		MoveWindow(m_hWindow, WindowRect.left, WindowRect.top, width + WindowRect.right - ClientRect.right, height + WindowRect.bottom - ClientRect.bottom, FALSE);
	}

	ShowWindow(m_hWindow, SW_SHOWNORMAL);
	UpdateWindow(m_hWindow);

	return true;
}

bool CSmVideoGL::m_IntializeGL(long w, long h, long depth, bool bIsFullScreen)
{
	PIXELFORMATDESCRIPTOR pfDesc;
	int format;

	m_hDC    = GetDC(m_hWindow);
	m_width  = (float) w;
	m_height = (float) h;
	
	memset(&pfDesc, 0, sizeof(pfDesc));

	pfDesc.nSize      = sizeof(PIXELFORMATDESCRIPTOR);
	pfDesc.nVersion   = 1;
	pfDesc.dwFlags    = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
	pfDesc.iPixelType = PFD_TYPE_RGBA;
	pfDesc.cColorBits = 24;
	pfDesc.cDepthBits = 16;
	pfDesc.iLayerType = PFD_MAIN_PLANE;
	format            = ChoosePixelFormat(m_hDC, &pfDesc);
	SetPixelFormat(m_hDC, format, &pfDesc);
	
	m_hRC = wglCreateContext(m_hDC);
	wglMakeCurrent(m_hDC, m_hRC);

	return true;
}

bool CSmVideoGL::m_IntializeState(void)
{
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);

	glEnable(GL_LIGHTING);
	GLfloat ambient[] = {1.0f, 1.0f, 1.0f, 1.0f};
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient);

	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);

	glEnable(GL_LIGHT0);
	{
		GLfloat ambient[] = {0.0f, 0.3f, 0.3f, 1.0f};
		glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);

		GLfloat diffuse[] = {0.7f, 0.7f, 0.7f, 1.0f};
		glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);

		GLfloat specular[] = {1.0f, 1.0f, 1.0f, 1.0f};
		glLightfv(GL_LIGHT0, GL_SPECULAR, specular);

		GLfloat light[] = {-100.0f, 0.0f, 100.0f, 1.0f};
		glLightfv(GL_LIGHT0, GL_POSITION, light);

		GLfloat specularRef[] = {1.0f, 1.0f, 1.0f, 1.0f};
		glMaterialfv(GL_FRONT, GL_SPECULAR, specularRef);

		glMateriali(GL_FRONT, GL_SHININESS, 128);
	}

//	glEnable(GL_CULL_FACE);

	return true;
}

bool CSmVideoGL::Create(long w, long h, long depth, bool bIsFullScreen)
{
	CHECK_FAILED(m_IntializeWindow(w, h))
	CHECK_FAILED(m_IntializeGL(w, h, depth, bIsFullScreen))
	CHECK_FAILED(m_IntializeState())

	this->Clear(0x000000FF);
	this->Flush();

	return true;
}

bool CSmVideoGL::Destroy(void)
{
	wglMakeCurrent(NULL, NULL);
	wglDeleteContext(m_hRC);
	ReleaseDC(m_hWindow, m_hDC);

	return true;
}

bool CSmVideoGL::IsValid(void) const
{
	return (m_hRC != 0);
}

bool CSmVideoGL::BeginScene(void) const
{
	this->Clear(0x00000000);

	glViewport(0, 0, 800, 600);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glFrustum(-c_xViewport, c_xViewport, c_yViewport, -c_yViewport, c_xViewport*c_scaleFactor/2, 10000.0f);
	glScalef(1.0f, 1.0f, -1.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	return true;
}

bool CSmVideoGL::EndScene(void) const
{
	glFlush();

	return true;
}

bool CSmVideoGL::Flush(void) const
{
	SwapBuffers(m_hDC);

	return true;
}

bool CSmVideoGL::Clear(PIXEL color) const
{
	float s = 1.0f / 256.0f;
	float z = 1.0f;

	glClearColor(((color>>16)&0xff) * s, ((color>>8)&0xff) * s, (color&0xff) * s, 0.0f);
	glClearDepth(GLclampd(z));
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	return true;
}

long CSmVideoGL::CreateImage(long w, long h, unsigned long usage) const
{
	GLuint ixTexture;
	int    realW, realH;

	glGenTextures(1, &ixTexture);
	glBindTexture(GL_TEXTURE_2D, ixTexture);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	realW = 4;
	while (w > realW)
		realW <<= 1;

	realH = 4;
	while (h > realH)
		realH <<= 1;

	GLTEXTURE* pTexture      = new GLTEXTURE;

	pTexture->wSize          = w;
	pTexture->hSize          = h;
	pTexture->wTexture       = realW;
	pTexture->hTexture       = realH;
	pTexture->ixTexture      = ixTexture;
	pTexture->isStaticBuffer = true;
	pTexture->pMemAddr       = NULL;

	return long(pTexture);
}

bool CSmVideoGL::DestroyImage(long image) const
{
	CHECK_FAILED(image)

	GLTEXTURE* pTexture = (GLTEXTURE*)image;

	if (!pTexture->isStaticBuffer)
		delete[] pTexture->pMemAddr;

	glDeleteTextures(1, (GLuint*)&pTexture->ixTexture);

	delete pTexture;

	return true;
}

bool CSmVideoGL::AssignImage(long image, PIXEL* pBuffer, long w, long h, long pitch, long depth) const
{
	CHECK_FAILED(image)

	GLTEXTURE* pTexture = (GLTEXTURE*)image;

	if (pitch == 0)
		pitch = w;

	pTexture->isStaticBuffer = false;
	pTexture->pMemAddr = (PIXEL*)new char[pTexture->wTexture * pTexture->hTexture * sizeof(PIXEL)];

	switch (depth)
	{
	case 32:
		{
			PIXEL* pSour32 = pBuffer;
			PIXEL* pDest32 = pTexture->pMemAddr;
			PIXEL  color;
			unsigned char* pTemp = (unsigned char*) &color;
			int    srcPadding = pitch - w;
			int    dstPadding = pTexture->wTexture - w;

			for (int j = 0; j < h; j++)
			{
				for (int i = 0; i < w; i++)
				{
					color = *pSour32++;

					pTemp[0] ^= pTemp[2];
					pTemp[2] ^= pTemp[0];
					pTemp[0] ^= pTemp[2];

					*pDest32++ = color;
				}
				pSour32 += srcPadding;
				pDest32 += dstPadding;
			}
			break;
		}
	case 24:
		{
			PIXEL* pDest32 = pTexture->pMemAddr;
			PIXEL  color;
			unsigned char* pTemp = (unsigned char*) &color;
			int    dstPadding = pTexture->wTexture - w;

			for (int j = 0; j < h; j++)
			{
				unsigned char* pSour08 = (unsigned char*)((char*)pBuffer + j * pitch);
				for (int i = 0; i < w; i++)
				{
					pTemp[2] = *pSour08++;
					pTemp[1] = *pSour08++;
					pTemp[0] = *pSour08++;
					pTemp[3] = 0xFF;

					*pDest32++ = color;
				}
				pDest32 += dstPadding;
			}
			break;
		}
	}

	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, pTexture->wTexture, pTexture->hTexture, 0, GL_RGBA, GL_UNSIGNED_BYTE, pTexture->pMemAddr);

	return true;
}

bool CSmVideoGL::GetImageAttr(long image, long& w, long& h) const
{
	CHECK_FAILED(image)

	GLTEXTURE* pTexture = (GLTEXTURE*)image;

	w = pTexture->wSize;
	h = pTexture->hSize;

	return true;
}

bool CSmVideoGL::DrawImage(long xDest, long yDest, long image, long xSour, long ySour, long w, long h, PIXEL color) const
{
	GLTEXTURE* pTexture = (GLTEXTURE*)image;

	glEnable(GL_TEXTURE_2D);

	GLfloat x1 = float(xDest);
	GLfloat y1 = float(yDest);
	GLfloat x2 = x1 + float(w);
	GLfloat y2 = y1 + float(h);
	GLfloat u1 = float(xSour) / pTexture->wTexture;
	GLfloat u2 = u1 + float(w) / pTexture->wTexture;
	GLfloat v1 = float(ySour) / pTexture->hTexture;
	GLfloat v2 = v1 + float(h) / pTexture->hTexture;

	glLoadIdentity();
	glPushMatrix();

	glTranslatef(0.0f, 0.0f, c_xViewport*c_scaleFactor);
	glScalef(c_scaleFactor, c_scaleFactor, c_scaleFactor);

	glBegin(GL_TRIANGLE_STRIP);

		glBindTexture(GL_TEXTURE_2D, pTexture->ixTexture);

		glColor4f(1.0f, 1.0f, 1.0f, 1.0f); 

		glTexCoord2f(u1, v1); glVertex3f(x1, y1, 100.0f);
		glTexCoord2f(u1, v2); glVertex3f(x1, y2, 100.0f);
		glTexCoord2f(u2, v1); glVertex3f(x2, y1, 100.0f);
		glTexCoord2f(u2, v2); glVertex3f(x2, y2, 100.0f);

	glEnd();

	glPopMatrix();

	return true;
}

void CSmVideoGL::_Test(long image[]) const
{
}
