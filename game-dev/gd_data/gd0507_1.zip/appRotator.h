
#ifndef APP_ROTATOR_H
#define APP_ROTATOR_H

#include "smType.h"

class CRotator: public ISmActor
{
public:
	unsigned long DoAction(long refTime, ISmActor* pSender = 0);
};

#endif
