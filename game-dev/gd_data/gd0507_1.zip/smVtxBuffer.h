
#ifndef SM_VTX_BUFFER_H
#define SM_VTX_BUFFER_H

#include "smType.h"
#include "smVideo.h"

class CSmVertexBuffer: public ISmActor
{
public:
	typedef struct
	{
		float scale;

		float color[4];
		float vertex[4][3];

		long  image;
		float uv[4][2];
	} VERTEX;

private:
	ISmActor* m_pActor;
	CSmRenderer* m_pRenderer;

	int       m_nVertices;
	VERTEX*   m_pVertices;
	float     m_angle[3];

public:
	CSmVertexBuffer(VERTEX *pSmVertices, int num);
	~CSmVertexBuffer(void);

	inline  void  SetAngleX(float angle) { m_angle[0] = angle; }
	inline  void  SetAngleY(float angle) { m_angle[1] = angle; }
	inline  void  SetAngleZ(float angle) { m_angle[2] = angle; }
	inline  float GetAngleX(void) { return m_angle[0]; }
	inline  float GetAngleY(void) { return m_angle[1]; }
	inline  float GetAngleZ(void) { return m_angle[2]; }

	void SetActor(ISmActor* pActor);
	void SetRenderer(CSmRenderer* pRenderer);

	unsigned long DoAction(long refTime, ISmActor* pSender = 0);
	virtual  void Render(void);
};

#endif
