
#ifndef SM_APP_H
#define SM_APP_H

#include "smType.h"
#include "smVideo.h"

class CSmApplication: public ISmActor
{
private:
	ISmVideo* m_pVideo;

protected:

public:
	CSmApplication(void);
	virtual ~CSmApplication(void);

	unsigned long DoAction(long refTime, ISmActor* pSender = 0);

	inline  const ISmVideo&  DisplayDevice(void) { return *m_pVideo; };

	virtual void OnCreate(void)  {};
	virtual void OnDestroy(void) {};
	virtual void OnProcess(void) {};
};

#endif
