
#include "appBgActor.h"
#include "smVideoGL.h"
#include <assert.h>

CBackgroundActor::CBackgroundActor(long image)
{
	assert(image);

	m_image = image;

	GLTEXTURE* pTexture = (GLTEXTURE*)m_image;

	m_xDest = -c_xViewport - pTexture->wSize;
	m_yDest = -c_yViewport - pTexture->hSize;
}

unsigned long CBackgroundActor::DoAction(long refTime, ISmActor* pSender)
{
	GLTEXTURE* pTexture = (GLTEXTURE*)m_image;

	m_xDest += 1.0f;
	m_yDest += 1.0f;

	if (m_xDest > -c_xViewport)
		m_xDest = -c_xViewport - pTexture->wSize + 1.0f;
	if (m_yDest > -c_yViewport)
		m_yDest = -c_yViewport - pTexture->hSize + 1.0f;

	return 0;
}

void CBackgroundActor::Render(void)
{
	glEnable(GL_TEXTURE_2D);

	glMatrixMode(GL_PROJECTION);

	glLoadIdentity();
	glOrtho(-c_xViewport, c_xViewport, c_yViewport, -c_yViewport, c_xViewport*c_scaleFactor/2, 10000.0f);
	glScalef(1.0f, 1.0f, -1.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	{
		GLTEXTURE* pTexture = (GLTEXTURE*)m_image;

		GLfloat x1 = float(m_xDest);
		GLfloat y1 = float(m_yDest);
		GLfloat x2 = x1 + float(pTexture->wSize);
		GLfloat y2 = y1 + float(pTexture->hSize);
		GLfloat u1 = 0.0f;
		GLfloat u2 = u1 + float(pTexture->wSize) / pTexture->wTexture;
		GLfloat v1 = 0.0f;
		GLfloat v2 = v1 + float(pTexture->hSize) / pTexture->hTexture;

		glBindTexture(GL_TEXTURE_2D, pTexture->ixTexture);

		while (y1 < c_yViewport)
		{
			x1 = float(m_xDest);
			x2 = x1 + float(pTexture->wSize);
			while (x1 < c_xViewport)
			{
				glBegin(GL_TRIANGLE_STRIP);
					glColor4f(1.0f, 1.0f, 1.0f, 1.0f); 

					glTexCoord2f(u1, v1); glVertex3f(x1, y1, 10000.0f);
					glTexCoord2f(u1, v2); glVertex3f(x1, y2, 10000.0f);
					glTexCoord2f(u2, v1); glVertex3f(x2, y1, 10000.0f);
					glTexCoord2f(u2, v2); glVertex3f(x2, y2, 10000.0f);
				glEnd();

				x1 = x2;
				x2 = x1 + float(pTexture->wSize);
			}
			y1 = y2;
			y2 = y1 + float(pTexture->hSize);
		}
	}

	glMatrixMode(GL_PROJECTION);

	glLoadIdentity();
	glFrustum(-c_xViewport, c_xViewport, c_yViewport, -c_yViewport, c_xViewport*c_scaleFactor/2, 10000.0f);
	glScalef(1.0f, 1.0f, -1.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}
