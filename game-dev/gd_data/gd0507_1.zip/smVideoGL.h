
#ifndef SM_VIDEO_GL_H
#define SM_VIDEO_GL_H

#include <windows.h>
#include <gl/gl.h>
#include "smVideo.h"

typedef struct tagORZ_TEXTURE
{
	long   wSize;
	long   hSize;
	long   wTexture;
	long   hTexture;
	GLuint ixTexture;
	bool   isStaticBuffer;
	PIXEL* pMemAddr;
} GLTEXTURE, *PGLTEXTURE;

class CSmVideoGL: public ISmVideo
{
private:
	HINSTANCE m_hInstance;
	HGLRC m_hRC;
	HWND  m_hWindow;
	HDC	  m_hDC;
	float m_width;
	float m_height;

	bool  m_IntializeWindow(long width, long height);
	bool  m_IntializeGL(long w, long h, long depth, bool bIsFullScreen);
	bool  m_IntializeState(void);

public:
	CSmVideoGL(HINSTANCE hInstance);
	~CSmVideoGL(void);

	bool Create       (long w, long h, long depth, bool bIsFullScreen);
	bool Destroy      (void);
	bool IsValid      (void) const;

	bool BeginScene   (void) const;
	bool EndScene     (void) const;
	bool Flush        (void) const;

	bool Clear        (PIXEL color) const;

	long CreateImage  (long w, long h, unsigned long usage = CREATEIMAGE_USAGE_IMAGE) const;
	bool DestroyImage (long image) const;
	bool AssignImage  (long image, PIXEL* pBuffer, long w, long h, long pitch = 0, long depth = 32) const;
	bool GetImageAttr (long image, long& w, long& h) const;

	bool DrawImage    (long xDest, long yDest, long image, long xSour, long ySour, long w, long h, PIXEL color = 0xFFFFFFFF) const;

	void _Test        (long ixTexture[]) const;
};

#endif
