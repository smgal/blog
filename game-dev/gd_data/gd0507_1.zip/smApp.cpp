
#include <windows.h>
#include "smApp.h"

CSmApplication::CSmApplication(void)
{
	m_pVideo = static_cast<ISmVideo*>(GetVideoInstance());
}

CSmApplication::~CSmApplication(void)
{
}

unsigned long CSmApplication::DoAction(long refTime, ISmActor* pSender)
{
	OnCreate();

	while (TRUE)
	{
		MSG  uMsg;

		if (PeekMessage(&uMsg, 0, 0, 0, PM_NOREMOVE))
		{
			if (GetMessage(&uMsg, 0, 0, 0) == 0)
				break;
			TranslateMessage(&uMsg);
			DispatchMessage(&uMsg);
		}
		else
		{
			OnProcess();
			// WaitMessage();
		}
	}

	OnDestroy();

	return 0;
}
