
#ifndef SM_TYPE_H
#define SM_TYPE_H

const int c_screenWidth  = 800;
const int c_screenHeight = 600;
const int c_screenDepth  = 32;

const float c_xViewport  = c_screenWidth  / 2;
const float c_yViewport  = c_screenHeight / 2;
const float c_zViewport  = c_xViewport;
const float c_scaleFactor = 4.0f;

class ISmActor
{
public:
	virtual unsigned long DoAction(long refTime, ISmActor* pSender = 0) = 0;
};

#endif
