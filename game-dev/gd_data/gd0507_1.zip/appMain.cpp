
#include "smApp.h"
#include "smVtxBuffer.h"

////////////////////////////////

#include <vector>

typedef std::vector<long*> IMAGE_POOL;
typedef std::vector<CSmVertexBuffer*> VERTEX_POOL;

#define MAX_IMAGE 2

class CMyApp: public CSmApplication 
{
private:
	long image[MAX_IMAGE];
	VERTEX_POOL vtxBuffer;

protected:

public:
	CMyApp(void) {};
	~CMyApp(void) {};

	void OnCreate(void);
	void OnDestroy(void);
	void OnProcess(void);
};

////////////////////////////////

#include "appRotator.h"
#include "appBgActor.h"
#include <windows.h>
#include <assert.h>

static long LoadBMP(const ISmVideo& video, const char* szFileName)
{
	long image = 0;

	{
		HBITMAP hBmp;
		BITMAP  bmp;

		hBmp = (HBITMAP)LoadImage(0, szFileName, IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_LOADFROMFILE | LR_DEFAULTSIZE);

		if (hBmp)
		{
			GetObject(hBmp, sizeof(bmp), &bmp);
			
			image = video.CreateImage(bmp.bmWidth, bmp.bmHeight);
			video.AssignImage(image, (PIXEL*)((char*)bmp.bmBits + bmp.bmWidthBytes * (bmp.bmHeight-1)), bmp.bmWidth, bmp.bmHeight, -bmp.bmWidthBytes, bmp.bmBitsPixel); 

			DeleteObject(hBmp);
		}
	}

	return image;
}

void CMyApp::OnCreate(void)
{
	const ISmVideo& video = this->DisplayDevice();
	assert(&video);

	ZeroMemory(&image, sizeof(image));

	image[0] = LoadBMP(video, "./a.bmp");
	image[1] = LoadBMP(video, "./b.bmp");

	CSmVertexBuffer* pVB;

	{
		pVB = new CSmVertexBuffer(NULL, 0);
		assert(pVB);
		pVB->SetRenderer(new CBackgroundActor(image[1]));

		vtxBuffer.push_back(pVB);
	}

	{
		const float xDefaultAngle = -30.0f;
		const float yDefaultAngle =  55.0f;
		const float zDefaultAngle =   0.0f;
		const float defaultScale  =  70.0f;

		long  wTemp;
		long  hTemp;
		float wImage;
		float hImage;

		video.GetImageAttr(image[0], wTemp, hTemp);

		wImage = float(wTemp);
		hImage = float(hTemp);

		CSmVertexBuffer::VERTEX vertices1[] =
		{
			{	defaultScale,
				{1.0f, 1.0f, 1.0f, 1.0f},
				{{-1.0f, -1.0f, -1.0f}, {-1.0f,  1.0f, -1.0f}, { 1.0f, -1.0f, -1.0f}, { 1.0f,  1.0f, -1.0f}},
				image[0],
				{{0.0f, 0.0f}, {0.0f, hImage}, {wImage, 0.0f}, {wImage, hImage}}
			},
			{	defaultScale,
				{1.0f, 0.0f, 0.0f, 1.0f},
				{{ 1.0f, -1.0f, -1.0f}, { 1.0f,  1.0f, -1.0f}, { 1.0f, -1.0f,  1.0f}, { 1.0f,  1.0f,  1.0f}},
				image[0],
				{{0.0f, 0.0f}, {0.0f, hImage}, {wImage, 0.0f}, {wImage, hImage}}
			},
			{	defaultScale,
				{0.0f, 1.0f, 0.0f, 1.0f},
				{{ 1.0f, -1.0f,  1.0f}, { 1.0f,  1.0f,  1.0f}, {-1.0f, -1.0f,  1.0f}, {-1.0f,  1.0f,  1.0f}},
				image[0],
				{{0.0f, 0.0f}, {0.0f, hImage}, {wImage, 0.0f}, {wImage, hImage}}
			},
			{	defaultScale,
				{0.0f, 0.0f, 1.0f, 1.0f},
				{{-1.0f, -1.0f,  1.0f}, {-1.0f,  1.0f,  1.0f}, {-1.0f, -1.0f, -1.0f}, {-1.0f,  1.0f, -1.0f}},
				image[0],
				{{0.0f, 0.0f}, {0.0f, hImage}, {wImage, 0.0f}, {wImage, hImage}}
			},
			{	defaultScale,
				{1.0f, 0.0f, 1.0f, 1.0f},
				{{-1.0f, -1.0f,  1.0f}, {-1.0f, -1.0f, -1.0f}, { 1.0f, -1.0f,  1.0f}, { 1.0f, -1.0f, -1.0f}},
				image[0],
				{{0.0f, 0.0f}, {0.0f, hImage}, {wImage, 0.0f}, {wImage, hImage}}
			},
			{	defaultScale,
				{1.0f, 1.0f, 0.0f, 1.0f},
				{{-1.0f,  1.0f, -1.0f}, {-1.0f,  1.0f,  1.0f}, { 1.0f,  1.0f, -1.0f}, { 1.0f,  1.0f,  1.0f}},
				image[0],
				{{0.0f, 0.0f}, {0.0f, hImage}, {wImage, 0.0f}, {wImage, hImage}}
			},
		};

		pVB = new CSmVertexBuffer(vertices1, sizeof(vertices1) / sizeof(vertices1[0]));
		assert(pVB);

		pVB->SetActor(new CRotator());

		pVB->SetAngleX(xDefaultAngle);
		pVB->SetAngleY(yDefaultAngle);
		pVB->SetAngleZ(zDefaultAngle);

		vtxBuffer.push_back(pVB);

		for (int i = 0; i < sizeof(vertices1) / sizeof(vertices1[0]); i++)
		{
			vertices1[i].scale = vertices1[i].scale * 1.3f;
			vertices1[i].color[3] = 0.4f;
		}

		pVB = new CSmVertexBuffer(vertices1, sizeof(vertices1) / sizeof(vertices1[0]));
		assert(pVB);

		pVB->SetActor(new CRotator());

		pVB->SetAngleX(xDefaultAngle);
		pVB->SetAngleY(yDefaultAngle);
		pVB->SetAngleZ(zDefaultAngle);

		vtxBuffer.push_back(pVB);
	}
}

void CMyApp::OnDestroy(void)
{
	const ISmVideo& video = this->DisplayDevice();
	assert(&video);

	for (VERTEX_POOL::iterator object = vtxBuffer.begin(); object != vtxBuffer.end(); ++object)
		delete (*object);

	for (int i = 0; i < MAX_IMAGE; i++)
		video.DestroyImage(image[i]);
}

void CMyApp::OnProcess(void)
{
	const ISmVideo& video = this->DisplayDevice();
	assert(&video);

	for (VERTEX_POOL::iterator object = vtxBuffer.begin(); object != vtxBuffer.end(); ++object)
		(*object)->DoAction(0);

	video.BeginScene();
	{
		for (VERTEX_POOL::iterator object = vtxBuffer.begin(); object != vtxBuffer.end(); ++object)
			(*object)->Render();
	}
	video.EndScene();

	video.Flush();

	Sleep(0);
}

////////////////////////////////

#if defined(WIN32) && defined(_DEBUG)
	extern "C" int __cdecl _CrtSetDbgFlag(int);
#endif

#if defined(WIN32) && defined(_DEBUG)
	#define ENABLE_LEAK_CHEKING _CrtSetDbgFlag(0x21);
#else
	#define ENABLE_LEAK_CHEKING
#endif

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{
	ENABLE_LEAK_CHEKING

	CMyApp app;

	app.DoAction(0);

	return 0;
}
