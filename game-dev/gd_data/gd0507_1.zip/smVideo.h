
#ifndef SM_VIDEO_H
#define SM_VIDEO_H

#include "smType.h"

typedef unsigned long PIXEL, *PPIXEL;

class ISmVideo
{
public:
	enum
	{
		CREATEIMAGE_USAGE_IMAGE        = 0,
		CREATEIMAGE_USAGE_RENDERTARGET = 1,
	};

	virtual bool Create       (long w, long h, long depth, bool bIsFullScreen) = 0;
	virtual bool Destroy      (void) = 0;
	virtual bool IsValid      (void) const = 0;

	virtual bool BeginScene   (void) const = 0;
	virtual bool EndScene     (void) const = 0;
	virtual bool Flush        (void) const = 0;

	virtual bool Clear        (PIXEL color) const = 0;

	virtual long CreateImage  (long w, long h, unsigned long usage = CREATEIMAGE_USAGE_IMAGE) const = 0;
	virtual bool DestroyImage (long image) const = 0;
	virtual bool AssignImage  (long image, PIXEL* pBuffer, long w, long h, long pitch = 0, long depth = 32) const = 0;
	virtual bool GetImageAttr (long image, long& w, long& h) const = 0;

	virtual bool DrawImage    (long xDest, long yDest, long image, long xSour, long ySour, long w, long h, PIXEL color = 0xFFFFFFFF) const = 0;
/*
	virtual bool Create       (void) = 0;
	virtual bool Clear        (PIXEL color, long x, long y, long w, long h) const = 0;
	virtual bool GetInfo      (PIXEL** ppBuffer, long* pW, long* pH, long* pPitch) const = 0;

	virtual bool Flush        (long x1, long y1, long x2, long y2) const = 0;


	virtual long CreateSprite (long image, long x, long y, long w, long h) const = 0;
	virtual bool DestroySprite(long sprite) const = 0;

	virtual bool FillRect     (PIXEL color, long x, long y, long w, long h) const = 0;
	virtual bool DrawSprite   (long x, long y, long sprite, unsigned long color = 0xFFFFFFFF) const = 0;
*/
	virtual void _Test        (long ixTexture[]) const = 0;
};

extern ISmVideo* GetVideoInstance(void);

class CSmRenderer: public ISmActor
{
public:
	virtual  void Render(void) = 0;
};

#endif
