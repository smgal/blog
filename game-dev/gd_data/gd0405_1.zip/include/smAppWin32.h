
#ifndef __SMAPPWIN32_H__
#define __SMAPPWIN32_H__

#include <windows.h>
#include "smAppWin32.h"
#include "smVideoWin32.h"

extern TCHAR  szTitle[];
extern TCHAR  szClass[];

typedef struct
{
	DWORD hInstance;
	LONG  width;
	LONG  height;
	LONG  depth;
	bool  isFullScreen;
} APPINIT_DESC;

class CSmAppWin32
{
private:

public:
	CSmAppWin32(void);
	~CSmAppWin32(void);

	bool Init(APPINIT_DESC& appInitDesc);
	bool Run(void);
	bool Done(void);
};

#endif // __SMAPPWIN32_H__
