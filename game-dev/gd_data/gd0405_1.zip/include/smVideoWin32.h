
#ifndef __SMVIDEOWIN32_H__
#define __SMVIDEOWIN32_H__

#include <windows.h>
#include <d3d9.h>
#include "smFontWin32.h"

#define BACKBUFFER_FORMAT D3DFMT_A8R8G8B8

class CSmVideoWin32
{
private:
	HINSTANCE m_hInstance;
	HWND      m_hWindow;

	IDirect3D9* m_pD3D;
	IDirect3DDevice9* m_pD3DDevice;

	CSmFontWin32* m_pSmFont;
	IDirect3DTexture9* m_fontTexture;

	bool m_IntializeWindow(long width, long height);
	void m_InitState(void);
	static LONG __stdcall m_WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

public:
	CSmVideoWin32(unsigned long hInstance);
	~CSmVideoWin32(void);

	bool Init(int width, int height, int depth, bool isFullScreen);
	bool Done(void);

	IDirect3DDevice9* Device(void) { return m_pD3DDevice; }
	void Render(IDirect3DTexture9* pTexture, float x, float y, float w, float h, float tu, float tv, float tw, float th, unsigned long color);
	void DrawText(int x, int y, char* szText, unsigned long color);
};

#endif // __SMVIDEOWIN32_H__
