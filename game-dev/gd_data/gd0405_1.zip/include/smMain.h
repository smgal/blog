
#ifndef __SMMAIN_H__
#define __SMMAIN_H__

class CSmMain
{
public:
	CSmMain();
	~CSmMain();

	bool Init();
	bool Run();
	bool Done();
};

#endif // __SMMAIN_H__
