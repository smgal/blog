
#ifndef __SMCONFIG_H__
#define __SMCONFIG_H__

#define SCREEN_WIDTH  640
#define SCREEN_HEIGHT 480
#define SCREEN_DEPTH  32

#define SM_FONTNAME "����"
#define SM_FONTSIZE 24

#endif // __SMCONFIG_H__
