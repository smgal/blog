
#ifndef __FONTTEST_H__
#define __FONTTEST_H__

/*******************************************+
| >> Include Section                        |
+*******************************************/

#include "smConfig.h"
#include "smAppWin32.h"
#include "smVideoWin32.h"
#include "smMain.h"

/*******************************************+
| >> Definition Section                     |
+*******************************************/

/*******************************************+
| >> External Definition Section            |
+*******************************************/

extern CSmVideoWin32* pSmVideo;
extern CSmMain* pSmMain;


#endif // __FONTTEST_H__
