
#ifndef __SMFONTWIN32_H__
#define __SMFONTWIN32_H__

#include <windows.h>
#include <d3d9.h>

class CSmFontWin32
{
private:
	IDirect3DTexture9* pTexture;
	D3DLOCKED_RECT m_lockRect;
	HDC   m_dc;
	HFONT m_font;
	HFONT m_oldFont;

public:
	CSmFontWin32(void);
	~CSmFontWin32(void);

	bool Init(DWORD hBuffer);
	bool DrawText(int x, int y, char* szText, unsigned long color, RECT* pRect = NULL);
};

#endif // __SMFONTWIN32_H__
