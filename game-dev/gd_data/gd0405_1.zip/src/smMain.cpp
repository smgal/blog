
#include <assert.h>
#include "fontTest.h"
#include "smVideoWin32.h"

CSmMain::CSmMain()
{
}

CSmMain::~CSmMain()
{
}

bool CSmMain::Init()
{
	return true;
}

bool CSmMain::Run()
{
	pSmVideo->Device()->Clear(0, NULL, D3DCLEAR_TARGET, 0xFF000000, 1.0, 0);

	pSmVideo->Device()->BeginScene();

	pSmVideo->DrawText(10, 10, "�ѱ� �׽�Ʈ�� �ٷ� �̰�!!", 0xFFFF0000);
	pSmVideo->DrawText(10, 40, "pSmVideo->DrawText(10, 40,.......", 0xFFFF00FF);
	pSmVideo->DrawText(10, 70, "��������� �ޫ���!", 0xFFFFFF00);

	pSmVideo->Device()->EndScene();
	pSmVideo->Device()->Present(NULL, NULL, NULL, NULL);

	return true;
}

bool CSmMain::Done()
{
	return true;
}
