
#include <windows.h>
#include <d3d9.h>
#include <assert.h>
#include "smVideoWin32.h"
#include "smFontWin32.h"

TCHAR  szTitle[] = TEXT("font test");
TCHAR  szClass[] = TEXT("SMgalFontClass");

#define CHECK_INVALID_TEXTURE(pTexture) \
	if (pTexture == NULL) \
		return;

#define CHECK_INVALID_DEVICE \
	assert(m_pD3DDevice);

#define CHECK_INVALID_FONT \
	if (m_pSmFont == NULL) \
		return;

#define FONT_TEXTURE_WIDTH   512
#define FONT_TEXTURE_HEIGHT  64

CSmVideoWin32::CSmVideoWin32(DWORD hInstance)
: m_hInstance(HINSTANCE(hInstance)), m_hWindow(0), m_pD3D(NULL), m_pD3DDevice(NULL),
  m_pSmFont(NULL), m_fontTexture(0)
{
}

CSmVideoWin32::~CSmVideoWin32()
{
}

bool CSmVideoWin32::m_IntializeWindow(long width, long height)
{
	HWND hWindow;

	if ((hWindow = FindWindow(szClass, szTitle)))
	{
		SetForegroundWindow((HWND)(((DWORD) hWindow) | 0x01));    
		return false;
	}

	WNDCLASS  wc;

    wc.style			= CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc		= (WNDPROC) m_WndProc;
    wc.cbClsExtra		= 0;
    wc.cbWndExtra		= 0;
    wc.hInstance		= m_hInstance;
    wc.hIcon			= LoadIcon(m_hInstance, 0);
    wc.hCursor			= 0;
    wc.hbrBackground	= (HBRUSH) GetStockObject(WHITE_BRUSH);
    wc.lpszMenuName		= 0;
    wc.lpszClassName	= szClass;

	if (RegisterClass(&wc) == 0)
		return false;

	DWORD style = WS_OVERLAPPED | WS_CAPTION | WS_VISIBLE | WS_SYSMENU;
	RECT rect;

	SetRect(&rect, 0, 0, width, height);
	AdjustWindowRect(&rect, style, false);
	hWindow = CreateWindow(szClass, szTitle, style,
	                       CW_USEDEFAULT, CW_USEDEFAULT, (rect.right - rect.left), (rect.bottom - rect.top),
						   NULL, NULL, m_hInstance, NULL);

	if (!hWindow)
		return false;

	SetCursor(LoadCursor(NULL, IDC_ARROW));

	ShowWindow(hWindow, SW_SHOWNORMAL);
	UpdateWindow(hWindow);

	m_hWindow = hWindow;

	return true;
}

LRESULT CALLBACK CSmVideoWin32::m_WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message) 
	{
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

void CSmVideoWin32::m_InitState()
{
	D3DMATERIAL9 material;
	ZeroMemory(&material, sizeof(material));
	material.Diffuse.r = 1; material.Diffuse.g = 1; material.Diffuse.b = 1;
	material.Ambient.r = 1; material.Ambient.g = 1; material.Ambient.b = 1;
	m_pD3DDevice->SetMaterial(&material);
	m_pD3DDevice->SetRenderState(D3DRS_AMBIENT, 0xFFFFFFFF);

	m_pD3DDevice->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, 0);
	m_pD3DDevice->SetTextureStageState(0, D3DTSS_COLORARG1,     D3DTA_TEXTURE);
	m_pD3DDevice->SetTextureStageState(0, D3DTSS_COLORARG2,     D3DTA_DIFFUSE);
	m_pD3DDevice->SetTextureStageState(0, D3DTSS_COLOROP,       D3DTOP_MODULATE);
	m_pD3DDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1,     D3DTA_TEXTURE);
	m_pD3DDevice->SetTextureStageState(0, D3DTSS_ALPHAARG2,     D3DTA_DIFFUSE);
	m_pD3DDevice->SetTextureStageState(0, D3DTSS_ALPHAOP,       D3DTOP_MODULATE);
	m_pD3DDevice->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pD3DDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);

	m_pD3DDevice->SetRenderState(D3DRS_ZENABLE, 0);
	m_pD3DDevice->SetRenderState(D3DRS_LIGHTING, 0);
	m_pD3DDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, 1);
	m_pD3DDevice->SetRenderState(D3DRS_ALPHATESTENABLE, 1);
	m_pD3DDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW); // D3DCULL_NONE

	m_pD3DDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pD3DDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	m_pD3DDevice->SetRenderState(D3DRS_DITHERENABLE, 0);
	m_pD3DDevice->SetRenderState(D3DRS_SPECULARENABLE, 0);
	m_pD3DDevice->SetRenderState(D3DRS_TEXTUREFACTOR, 0xFFFFFFFF);
	m_pD3DDevice->SetRenderState(D3DRS_SHADEMODE, D3DSHADE_GOURAUD);
	m_pD3DDevice->SetRenderState(D3DRS_ALPHAREF, 0x00);
	m_pD3DDevice->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);
}

bool CSmVideoWin32::Init(int width, int height, int depth, bool isFullScreen)
{
	if (!m_IntializeWindow(width, height))
		return false;

	D3DPRESENT_PARAMETERS d3dpp;

	m_pD3D = Direct3DCreate9(D3D_SDK_VERSION);
	if (m_pD3D == NULL)
		return false;

	ZeroMemory(&d3dpp, sizeof(d3dpp));

	d3dpp.SwapEffect       = D3DSWAPEFFECT_DISCARD;
	d3dpp.BackBufferCount  = 1;
	d3dpp.Flags            = D3DPRESENTFLAG_LOCKABLE_BACKBUFFER;

	if (isFullScreen)
	{
		d3dpp.Windowed         = FALSE;
		d3dpp.BackBufferFormat = BACKBUFFER_FORMAT;
		d3dpp.BackBufferWidth  = width;
		d3dpp.BackBufferHeight = height;
		if (FAILED(m_pD3D->CheckDeviceType(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, BACKBUFFER_FORMAT, BACKBUFFER_FORMAT, FALSE)))
			d3dpp.BackBufferFormat = D3DFMT_R5G6B5;
	}
	else
	{
		d3dpp.Windowed         = TRUE;
		d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;
	}

	if (FAILED(m_pD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, m_hWindow,
								    D3DCREATE_SOFTWARE_VERTEXPROCESSING,
								    &d3dpp, &m_pD3DDevice)))
		return false;

	{
		D3DVIEWPORT9 viewPort;

		viewPort.X      = 0;
		viewPort.Y      = 0;
		viewPort.Width  = width;
		viewPort.Height = height;
		viewPort.MinZ   = 0.0;
		viewPort.MaxZ   = 1.0;
		m_pD3DDevice->SetViewport(&viewPort);
	}

	m_InitState();

	{
		m_pD3DDevice->CreateTexture(FONT_TEXTURE_WIDTH, FONT_TEXTURE_HEIGHT, 0, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &m_fontTexture, NULL);

		if (m_fontTexture)
		{
			m_pSmFont = new CSmFontWin32();
			m_pSmFont->Init(DWORD(m_fontTexture));
		}
	}


	return true;
}

bool CSmVideoWin32::Done()
{
	if (m_pSmFont)
	{
		delete m_pSmFont;
		m_pSmFont = NULL;
	}

	if (m_fontTexture)
	{
		m_fontTexture->Release();
		m_fontTexture = NULL;
	}

	if (m_hWindow)
	{
		DestroyWindow(m_hWindow);
		m_hWindow = 0;
	}

	return true;
}

void CSmVideoWin32::DrawText(int x, int y, char* szText, DWORD color)
{
	CHECK_INVALID_FONT

	RECT rect;
	float  w, h;

	if (m_pSmFont->DrawText(5, 5, szText, color, &rect))
	{
		w = float(rect.right - rect.left);
		h = float(rect.bottom - rect.top);
		this->Render(m_fontTexture, float(x), float(y), w, h, 0.0, 0.0, w / FONT_TEXTURE_WIDTH, h / FONT_TEXTURE_HEIGHT, 0xFFFFFFFF);
	}
}

void CSmVideoWin32::Render(IDirect3DTexture9* pTexture, float x, float y, float w, float h, float tu, float tv, float tw, float th, DWORD color)
{
	CHECK_INVALID_DEVICE
	CHECK_INVALID_TEXTURE(pTexture)

	struct tagVERTEX
	{
		float x, y, z, rhw;
		DWORD color;
		float tu, tv;
	} vertices[4];

	vertices[0].x = x - 0.5f;
	vertices[0].y = y - 0.5f;
	vertices[0].z = 0.0;
	vertices[0].rhw = 1.0;
	vertices[0].tu = tu;
	vertices[0].tv = tv;
	vertices[0].color = color;

	vertices[1].x = x + w - 0.5f;
	vertices[1].y = y - 0.5f;
	vertices[1].z = 0.0;
	vertices[1].rhw = 1.0;
	vertices[1].tu = tu + tw;
	vertices[1].tv = tv;
	vertices[1].color = color;

	vertices[2].x = x + w - 0.5f;
	vertices[2].y = y + h - 0.5f;
	vertices[2].z = 0.0;
	vertices[2].rhw = 1.0;
	vertices[2].tu = tu + tw;
	vertices[2].tv = tv + th;
	vertices[2].color = color;

	vertices[3].x = x - 0.5f;
	vertices[3].y = y + h - 0.5f;
	vertices[3].z = 0.0;
	vertices[3].rhw = 1.0;
	vertices[3].tu = tu;
	vertices[3].tv = tv + th;
	vertices[3].color = color;

	m_pD3DDevice->SetTexture(0, pTexture);
	m_pD3DDevice->SetFVF(D3DFVF_XYZRHW | D3DFVF_TEX1 | D3DFVF_DIFFUSE);
	m_pD3DDevice->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, vertices, sizeof(vertices) / 4);
}
