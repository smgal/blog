
#include <windows.h>
#include <d3d9.h>
#include "smFontWin32.h"
#include "smConfig.h"


CSmFontWin32::CSmFontWin32(void)
: pTexture(NULL), m_dc(0), m_font(0), m_oldFont(0)
{
	m_lockRect.pBits = NULL;
}

CSmFontWin32::~CSmFontWin32(void)
{
	if (m_oldFont)
		SelectObject(m_dc, m_oldFont);

	DeleteObject(m_font);
	DeleteDC(m_dc);
}

bool CSmFontWin32::Init(DWORD hBuffer)
{
	pTexture = (IDirect3DTexture9*)hBuffer;

	m_dc = CreateCompatibleDC(0);
	m_font = CreateFont(SM_FONTSIZE, 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET,
			OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_DONTCARE, SM_FONTNAME);
	m_oldFont = (HFONT)SelectObject(m_dc, m_font);

	return true;
}

bool CSmFontWin32::DrawText(int xPos, int yPos, char* szText, unsigned long color, RECT* pRect)
{
	MAT2   matrix;
	DWORD   bufSize;
	PBYTE  pBuffer;
	int    x, y;
	PBYTE  pSrc08;
	int    srcPadding;
	int    dstPadding;
	PDWORD  pDst32;
	DWORD   gray;
	int    index;
	DWORD   code;
	int    xInc, yInc;
	bool   isFirstChar;

	RECT   dirtyRect;
	GLYPHMETRICS   glyph;

	DWORD sR, sG, sB;
	DWORD rR, rG, rB;

	sR = (color >> 16) & 0x000000FF;;
	sG = (color >> 8) & 0x000000FF;;
	sB = color & 0x000000FF;

	ZeroMemory(&dirtyRect, sizeof(dirtyRect));

	ZeroMemory(&matrix, sizeof(matrix));
	matrix.eM11.value = 1;
	matrix.eM22.value = 1;

	xInc  = 0;
	yInc  = 0;
	index = 0;
	isFirstChar = true;
	color &= 0x00FFFFFF;

	if (pTexture->LockRect(0, &m_lockRect, NULL, 0) != D3D_OK)
		return false;

	{
		D3DSURFACE_DESC  textureDesc;
		pTexture->GetLevelDesc(0, &textureDesc);

		for (int y = 0; y < int(textureDesc.Height); ++y)
		{
			ZeroMemory(PBYTE(m_lockRect.pBits) + y * m_lockRect.Pitch, textureDesc.Width * 4);
		}
	}

	while (index < int(strlen(szText)))
	{
		code = DWORD(BYTE(szText[index++]));
		if (code > 0x7F)
			code = (code << 8) | DWORD(BYTE(szText[index++]));

		bufSize = GetGlyphOutline(m_dc, code, GGO_GRAY8_BITMAP, &glyph, 0, NULL, &matrix);
		if (bufSize == GDI_ERROR)
			break;

		if (bufSize > 0)
		{
			pBuffer = new BYTE[bufSize];
			GetGlyphOutline(m_dc, code, GGO_GRAY8_BITMAP, &glyph, bufSize, pBuffer, &matrix);

			if (!isFirstChar)
			{
				xPos += (xInc + glyph.gmptGlyphOrigin.x);
				yPos -= (yInc + glyph.gmptGlyphOrigin.y);
			}

			pSrc08  = pBuffer;
			srcPadding = (4 - glyph.gmBlackBoxX % 4) % 4;

			pDst32  = PDWORD(PBYTE(m_lockRect.pBits) + yPos * m_lockRect.Pitch) + xPos;
			dstPadding = (m_lockRect.Pitch - glyph.gmBlackBoxX * 4) >> 2;

			if (dirtyRect.left > xPos) 
				dirtyRect.left = xPos;
			if (dirtyRect.top > yPos) 
				dirtyRect.top = yPos;
			if (dirtyRect.right < xPos + int(glyph.gmBlackBoxX)) 
				dirtyRect.right = xPos + int(glyph.gmBlackBoxX);
			if (dirtyRect.bottom < yPos + int(glyph.gmBlackBoxY)) 
				dirtyRect.bottom = yPos + int(glyph.gmBlackBoxY);

			for (y = 0; y < int(glyph.gmBlackBoxY); ++y)
			{
				rR = sR * (glyph.gmBlackBoxY - y / 2) / glyph.gmBlackBoxY;
				rG = sG * (glyph.gmBlackBoxY - y / 2) / glyph.gmBlackBoxY;
				rB = sB * (glyph.gmBlackBoxY - y / 2) / glyph.gmBlackBoxY;

				color = (rR << 16) | (rG << 8) | (rB);

				for (x = 0; x < int(glyph.gmBlackBoxX); ++x)
				{
					if ((gray = DWORD(*pSrc08++)))
					{
						gray <<= 2;
						--gray;
						gray <<= 24;
						*pDst32++ = color | gray;
						continue;
					}
					*pDst32++ = color;
				}
				pSrc08 += srcPadding;
				pDst32 += dstPadding;
			}

			delete[] pBuffer;

			xInc = glyph.gmCellIncX - glyph.gmptGlyphOrigin.x;
			yInc = glyph.gmCellIncY - glyph.gmptGlyphOrigin.y;

			isFirstChar = false;
		}
		else
		{
			xPos += glyph.gmCellIncX;
			yPos += glyph.gmCellIncY;
		}
	}
	pTexture->UnlockRect(0);

	if (pRect)
		*pRect = dirtyRect;

	return true;
}
