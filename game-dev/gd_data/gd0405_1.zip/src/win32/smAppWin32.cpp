
#include "smAppWin32.h"
#include "smVideoWin32.h"
#include "fontTest.h"

#define CHECK_ASSIGNED(p) if ((p) == NULL) return false;
#define CHECK_RETURN(ret) if (!(ret)) return false;

CSmAppWin32::CSmAppWin32()
{
}

CSmAppWin32::~CSmAppWin32()
{
}

bool CSmAppWin32::Init(APPINIT_DESC& appInitDesc)
{
	bool result;

	pSmVideo = new CSmVideoWin32(appInitDesc.hInstance);
	CHECK_ASSIGNED(pSmVideo)

	result = pSmVideo->Init(appInitDesc.width, appInitDesc.height, appInitDesc.depth, appInitDesc.isFullScreen);
	CHECK_RETURN(result);

	pSmMain = new CSmMain();
	CHECK_ASSIGNED(pSmMain)

	result = pSmMain->Init();
	CHECK_RETURN(result);

	return true;
}

bool CSmAppWin32::Run()
{
	MSG msg;

	while (true)
	{
		if (PeekMessage(&msg, 0, 0, 0, PM_NOREMOVE))
		{
			if (GetMessage(&msg, 0, 0, 0) == 0)
				break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{
			pSmMain->Run();
			// WaitMessage();
		}
	}

	return true;
}

bool CSmAppWin32::Done()
{
	if (pSmMain)
	{
		pSmMain->Done();
		delete pSmMain;
		pSmMain = NULL;
	}

	if (pSmVideo)
	{
		pSmVideo->Done();
		delete pSmVideo;
		pSmVideo = NULL;
	}

	return true;
}
