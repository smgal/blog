
#include <windows.h>
#include "fontTest.h"

CSmVideoWin32* pSmVideo = NULL;
CSmMain* pSmMain = NULL;

int AppMain(HINSTANCE hInstance)
{
	CSmAppWin32  smApp;
	APPINIT_DESC appInitDesc;

	ZeroMemory(&appInitDesc, sizeof(appInitDesc));
	appInitDesc.hInstance    = UINT32(hInstance);
	appInitDesc.width        = SCREEN_WIDTH;
	appInitDesc.height       = SCREEN_HEIGHT;
	appInitDesc.depth        = SCREEN_DEPTH;
	appInitDesc.isFullScreen = false;

	smApp.Init(appInitDesc);
	smApp.Run();
	smApp.Done();

	return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{
	return AppMain(hInstance);
}
