 DeviceCaps Exporter v1.00
 http://www.adreniware.com/devicecaps/
 Copyright (C) 2004 Adreniware
 Andr� Jacobs

 This application will export the Direct3D Device Capabilities of your
 primary display adapter to the following files:

 DeviceCaps.dc     - The device caps information (used for submitting the results to 
                     dxcaps@adreniware.com).
 DeviceCaps.html   - Device capability information.
 DisplayModes.html - List of supported display modes and surface formats.

 * The application requires DirecX 9 to be installed.

 * Please submit any bugs or comments to dxcaps@adreniware.com

 ** Support this project by submitting your results "DeviceCaps.dc" file to
    dxcaps@adreniware.com

 Installation:
 -----------------------------------------

 Just extract the contents of DeviceCaps.zip to a folder and run
 DeviceCaps.exe

 Disclaimer:
 -----------------------------------------

 The author will not be responsible for any damage or loss that
 may occur from the use of this application.
 By using this application you are doing so at your own risk.

 * dsetup.dll is provided as it is found in the DirectX 9.0b distribution.
   The file is copyrighted by Microsoft.

 Thanks:
 -----------------------------------------  

 The guys from the original device caps databases www.molybdenium.de/devicecaps/
 and www.dxdevicecaps.com.

 Polygon for testing this application.

 Thank you for using and supporting this project.

                                                                 - Andre Jacobs
 